SELECT LoanCare.Loan.LoanNumber, LoanCare.Borrower.MortgagorLastName, LoanCare.Borrower.MortgagorFirstName, LoanCare.Property.PropertyStreetNumber, LoanCare.Property.CityName, LoanCare.Borrower.BillingAddressLine1, loancare.Borrower.BillingAddressLine4, loancare.Property.PropertyStreetAddress,
LoanCare.Borrower.BillingCityName, LoanCare.Borrower.BillingState, LoanCare.Property.OccupancyCode, LoanCare.Loan.InvestorId, LoanCare.OriginalLoan.NoteDate, LoanCare.OriginalLoan.NewLoanSetupDate, loancare.Property.OccupancyCurrentStatusCode,
LoanCare.OriginalLoan.OriginalMortgageAmount, LoanCare.Loan.FirstPrincipalBalance, LoanCare.MortgageInsurance.MiTerminationDate, LoanCare.OriginalLoan.OriginalLoanTerm, LoanCare.Loan.LoType, LoanCare.Loan.ArmIndicator, 
LoanCare.OriginalLoan.OriginalInterestRate, LoanCare.Loan.AnnualInterestRate, LoanCare.Loan.FirstPAndIAmount, LoanCare.Loan.EscrowedIndicator, LoanCare.Escrow.EscrowExpdAdvanceBalance, 
LoanCare.Loan.TotalMonthlyPayment, LoanCare.MortgageInsurance.MiMonthlyAmount, loancare.HazardInsurance.ForcedCoverageIndicator, LoanCare.Loan.LastFullPaymentDate, LoanCare.Loan.ForeclosureStatusCode, LoanCare.Foreclosure.FcSaleDate, LoanCare.Loan.LoanLossMitStatusCode, 
LoanCare.Loan.MspLastRunDate, LoanCare.LoanModification.LnModDate, LoanCare.LossMitigation.LossMitSetUpDate, LoanCare.LossMitigation.LossMitStatusChangeDate, LoanCare.Property.PropertyAlphaStateCode, 
LoanCare.Foreclosure.FcSetupDate, LOANCARE.Delinquency.DelinquencyIndicator, LoanCare.Delinquency.DelinquentPaymentCount
FROM (((((((LoanCare.Loan INNER JOIN LoanCare.Property ON (LoanCare.Loan.LoanNumber = LoanCare.Property.LoanNumber) AND (LoanCare.Loan.MspLastRunDate = LoanCare.Property.MspLastRunDate)) 
LEFT JOIN LoanCare.LossMitigation ON (LoanCare.Property.LoanNumber = LoanCare.LossMitigation.LoanNumber) AND (LoanCare.Property.MspLastRunDate = LoanCare.LossMitigation.MspLastRunDate)) 
LEFT JOIN LoanCare.LoanModification ON (LoanCare.Property.LoanNumber = LoanCare.LoanModification.LoanNumber) AND (LoanCare.Property.MspLastRunDate = LoanCare.LoanModification.MspLastRunDate)) 
LEFT JOIN LoanCare.Foreclosure ON (LoanCare.Property.LoanNumber = LoanCare.Foreclosure.LoanNumber) AND (LoanCare.Property.MspLastRunDate = LoanCare.Foreclosure.MspLastRunDate)) 
INNER JOIN LoanCare.Borrower ON (LoanCare.Property.MspLastRunDate = LoanCare.Borrower.MspLastRunDate) AND (LoanCare.Property.LoanNumber = LoanCare.Borrower.LoanNumber)) 
INNER JOIN LoanCare.OriginalLoan ON (LoanCare.Borrower.MspLastRunDate = LoanCare.OriginalLoan.MspLastRunDate) AND (LoanCare.Borrower.LoanNumber = LoanCare.OriginalLoan.LoanNumber)) 
inner join LOANCARE.HazardInsurance ON LOANCARE.OriginalLoan.LoanNumber = LOANCARE.HazardInsurance.LoanNumber AND LOANCARE.OriginalLoan.MspLastRunDate = LOANCARE.HazardInsurance.MspLastRunDate
LEFT JOIN LoanCare.MortgageInsurance ON (LoanCare.OriginalLoan.MspLastRunDate = LoanCare.MortgageInsurance.MspLastRunDate) AND (LoanCare.OriginalLoan.LoanNumber = LoanCare.MortgageInsurance.LoanNumber)) 
LEFT JOIN LoanCare.CorporateAdvTransactions ON (LoanCare.Property.MspLastRunDate = LoanCare.CorporateAdvTransactions.MspLastRunDate) AND (LoanCare.Property.LoanNumber = LoanCare.CorporateAdvTransactions.LoanNumber)
LEFT JOIN Loancare.Delinquency on (loancare.HazardInsurance.MspLastRunDate = loancare.Delinquency.MspLastRunDate AND LoanCare.HazardInsurance.LoanNumber = LoanCare.Delinquency.LoanNumber)
LEFT JOIN Loancare.Escrow on (loancare.HazardInsurance.MspLastRunDate = LoanCare.Escrow.MspLastRunDate AND LoanCare.HazardInsurance.LoanNumber = LOANCARE.Escrow.LoanNumber)
WHERE (((LoanCare.Loan.MspLastRunDate)>= '2020-02-01' And (LoanCare.Loan.MspLastRunDate)<= '2022-02-28') AND ((LoanCare.Property.PropertyAlphaStateCode)='WA'))
ORDER BY MspLastRunDate desc;
