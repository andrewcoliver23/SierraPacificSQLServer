WITH DMI_Serviced as (
SELECT (DAILYMASTERFIELDSLOAN.LoanNumber) AS LoanNumber, Cast(DAILYMASTERFIELDSLOAN.FirstPrincipalBalance as money) AS UPB, (DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE) AS DataDate
FROM DMI.DailyMasterFieldsLoan INNER JOIN DMI.DailyMasterFieldsProperty ON DMI.DAILYMASTERFIELDSLOAN.LoanNumber = DAILYMASTERFIELDSPROPERTY.LoanNumber AND 
DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE = DAILYMASTERFIELDSPROPERTY.MSPLASTRUNDATE
LEFT JOIN DMI.DailyMasterFieldsForeclosure ON DAILYMASTERFIELDSPROPERTY.LoanNumber = DailyMasterFieldsForeclosure.LoanNumber AND DAILYMASTERFIELDSPROPERTY.MSPLASTRUNDATE = DailymasterFieldsForeclosure.MSPLASTRUNDATE
WHERE DAILYMASTERFIELDSPROPERTY.PropertyAlphaStateCode = 'SC' AND DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE >= '2020-07-01'and dailymasterfieldsloan.msplastrundate <= '2021-12-31' 
and Cast(FirstPrincipalBalance as money) > 1),

LoanCare_Serviced as (
SELECT loan.loannumber AS LoanNumber, Cast(loan.firstprincipalbalance as money) as UPB,Loan.MspLastRunDate as DataDate
from loancare.loan inner join loancare.property on loan.loannumber = property.LoanNumber and loan.MspLastRunDate = property.MspLastRunDate
left join loancare.Foreclosure on Property.LoanNumber = Foreclosure.LoanNumber and Property.MspLastRunDate = Foreclosure.MspLastRunDate
where PropertyAlphaStateCode = 'SC' AND loan.MspLastRunDate >= '2020-07-01' and loan.msplastrundate <= '2021-12-31' and Cast(FirstPrincipalBalance as money) > 1),

ALL_SERVICED AS (
SELECT * FROM DMI_Serviced
UNION
SELECT * FROM LoanCare_Serviced),

All_SUMS AS (
select LoanNumber, min(UPB) AS UPB, MAX(DataDate) as DataDate
from ALL_SERVICED
group by LoanNumber),

LoanCareDelq as (
select LoanNumber,LoanNumber as AccountNumber, DelinquencyIndicator
from Loancare.Delinquency
where MspLastRunDate = '2022-06-29'),

PHH_DELQ AS (
SELECT Loan.LOAN_NBR_PRIOR_SRVCR, Loan.LOAN_NBR_SERVICER as AccountNumber,DELINQUENCY_INDICATOR
from PHH.Loan LEFT JOIN phh.Delinquency ON loan.LOAN_NBR_SERVICER = Delinquency.LOAN_NBR_SERVICER and loan.DATA_ASOF_DATE = Delinquency.DATA_ASOF_DATE
where LOAN.DATA_ASOF_DATE = '2022-06-29'),

ALL_DELQ AS (
SELECT * FROM LoanCareDelq
UNION
SELECT * FROM PHH_DELQ),


DMI_OtherFields as (
SELECT DMI.DailyMasterFieldsBorrower.MortgagorFirstName, DMI.DailyMasterFieldsBorrower.MortgagorLastName, DMI.DailyMasterFieldsLoan.LoanNumber as LoanNumber, DMI.DailyMasterFieldsLoan.AcquisitionDate, 
DMI.DailyMasterFieldsLoan.ArmIndicator, CAST(DMI.DailyMasterFieldsLoan.FirstPrincipalBalance AS MONEY) AS UPB, FORCED_COVERAGE_INDICATOR, LnModDate, OriginalMortgageAmount, OriginalLoanTerm, OriginalPropertyValueAmount, 
dmi.DailyMasterFieldsProperty.PropertyStreetAddress, 
dmi.DailyMasterFieldsProperty.PropertyZipCode,
DMI.DailyMasterFieldsLoan.MspLastRunDate as DataDate
FROM ((DMI.DailyMasterFieldsLoan INNER JOIN DMI.DailyMasterFieldsBorrower ON (DMI.DailyMasterFieldsLoan.MspLastRunDate = DMI.DailyMasterFieldsBorrower.MspLastRunDate) AND 
(DMI.DailyMasterFieldsLoan.LoanNumber = DMI.DailyMasterFieldsBorrower.LoanNumber)) INNER JOIN DMI.DailyMasterFieldsProperty ON (DMI.DailyMasterFieldsBorrower.MspLastRunDate = DMI.DailyMasterFieldsProperty.MspLastRunDate) 
AND (DMI.DailyMasterFieldsBorrower.LoanNumber = DMI.DailyMasterFieldsProperty.LoanNumber)) LEFT JOIN DMI.DailyMasterFieldsHazardInsurance ON 
(DMI.DailyMasterFieldsProperty.MspLastRunDate = DMI.DailyMasterFieldsHazardInsurance.MspLastRunDate) AND (DMI.DailyMasterFieldsProperty.LoanNumber = DMI.DailyMasterFieldsHazardInsurance.LoanNumber)
WHERE Cast(DMI.DailyMasterFieldsLoan.FirstPrincipalBalance as money) > 1 AND DMI.DailyMasterFieldsProperty.PropertyAlphaStateCode='SC' AND 
DMI.DailyMasterFieldsLoan.MspLastRunDate >= '2020-07-01'),

LoanCare_OtherFields as (
SELECT borrower.MortgagorFirstName, Borrower.MortgagorLastName, loan.loannumber AS LoanNumber, OriginalLoan.AcquisitionDate, Loan.ArmIndicator,
Cast(loan.firstprincipalbalance as money) as UPB, ForcedCoverageIndicator, LnModDate, LoanCare.OriginalLoan.OriginalMortgageAmount, OriginalLoan.OriginalLoanTerm, OriginalLoan.OriginalPropertyValueAmount, 
property.PropertyStreetAddress, 
property.PropertyZipCode, Loan.MspLastRunDate as DataDate
FROM ((((LoanCare.Loan INNER JOIN LoanCare.Property ON (LoanCare.Loan.MspLastRunDate = LoanCare.Property.MspLastRunDate) AND (LoanCare.Loan.LoanNumber = LoanCare.Property.LoanNumber)) 
INNER JOIN LoanCare.Borrower ON (LoanCare.Property.MspLastRunDate = LoanCare.Borrower.MspLastRunDate) AND (LoanCare.Property.LoanNumber = LoanCare.Borrower.LoanNumber)) 
INNER JOIN LoanCare.OriginalLoan ON (LoanCare.Borrower.MspLastRunDate = LoanCare.OriginalLoan.MspLastRunDate) AND (LoanCare.Borrower.LoanNumber = LoanCare.OriginalLoan.LoanNumber)) 
LEFT JOIN LoanCare.HazardInsurance ON (LoanCare.OriginalLoan.MspLastRunDate = LoanCare.HazardInsurance.MspLastRunDate) AND (LoanCare.OriginalLoan.LoanNumber = LoanCare.HazardInsurance.LoanNumber)) 
LEFT JOIN LoanCare.LoanModification ON (LoanCare.OriginalLoan.MspLastRunDate = LoanCare.LoanModification.MspLastRunDate) AND (LoanCare.OriginalLoan.LoanNumber = LoanCare.LoanModification.LoanNumber)
where PropertyAlphaStateCode = 'SC' AND loan.MspLastRunDate >= '2020-07-01' and Cast(FirstPrincipalBalance as money) > 1),

All_OtherFields as (
select * from DMI_OtherFields
union
select * from LoanCare_OtherFields)

SELECT all_otherfields.MortgagorFirstName, All_OtherFields.MortgagorLastName, All_SUMS.LoanNumber, AcquisitionDate, ArmIndicator, FORCED_COVERAGE_INDICATOR,LnModDate, OriginalMortgageAmount as LoanAmount,
OriginalLoanTerm as TermOfLoan,OriginalPropertyValueAmount as OriginalAppraisedValue, PropertyStreetAddress,PropertyZipCode,
DelinquencyIndicator, ALL_SUMS.DataDate, AccountNumber
from All_SUMS inner join All_OtherFields on All_SUMS.LoanNumber = All_OtherFields.LoanNumber and All_SUMS.DataDate = All_OtherFields.DataDate
left join ALL_DELQ on All_SUMS.LoanNumber = ALL_DELQ.LoanNumber