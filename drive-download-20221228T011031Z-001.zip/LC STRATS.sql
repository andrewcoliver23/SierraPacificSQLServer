SELECT InvestorId, count(LoanNumber), sum(cast(FirstPrincipalBalance as money)) FROM LoanCare.Loan
WHERE MspLastRunDate = '2022-11-30' AND CAST(FirstPrincipalBalance AS MONEY) >1 and LoanReoStatusCode <> 'A' AND LoanNumber not in ('0061820908', '0027890193')
group by InvestorId
