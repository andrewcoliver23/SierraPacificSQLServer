WITH LC_FNMA AS (SELECT L.LoanNumber, FirstPrincipalBalance, LoanTerm, LoanClosingDate, L.MspLastRunDate, InvestorId ,NextPaymentDueDate, ArmIndicator, datediff(mm, NextPaymentDueDateDelinquencyIndicator
FROM LoanCare.Loan L INNER JOIN LoanCare.OriginalLoan OL ON L.LoanNumber = OL.LoanNumber and l.MspLastRunDate = ol.MspLastRunDate
LEFT JOIN LoanCare.Delinquency D ON L.LoanNumber = D.LoanNumber AND L.MspLastRunDate = D.MspLastRunDate
WHERE L.MspLastRunDate = '2022-09-30' AND InvestorId IN ('4EF') and cast(FirstPrincipalBalance as money) > 1 AND ArmIndicator = 'N' and (DATEDIFF(mm,LoanClosingDate,LoanMaturesDate) >= 300 or cast(LoanTerm as smallint) >= 360 or cast(OriginalLoanTerm as smallint) >= 360)	),

PHH_FNMA AS (select L.LOAN_NBR_SERVICER, PRIN_BALANCE_CURR, TERM, LOAN_CLOSING_DATE, L.DATA_ASOF_DATE, INV_CODE, PMT_DUE_DATE_NEXT, ARM_FLAG, DELINQUENCY_INDICATOR
from phh.Loan l LEFT JOIN PHH.Delinquency D ON L.LOAN_NBR_SERVICER = D.LOAN_NBR_SERVICER AND L.DATA_ASOF_DATE = D.DATA_ASOF_DATE
LEFT JOIN [SPM.ExemptLoans] E ON L.LOAN_NBR_SERVICER = E.LoanNumber
WHERE INV_CODE IN ('47V') AND CAST(PRIN_BALANCE_CURR AS MONEY) > 1 AND L.DATA_ASOF_DATE = '2022-09-30' AND ARM_FLAG IN ('N') AND (datediff(mm, LOAN_CLOSING_DATE, MATURITY_DATE) >= 300  or cast(term as smallint) >= 360) and E.LoanNumber IS NULL), 

QUNION AS (SELECT * FROM LC_FNMA
UNION
SELECT * FROM PHH_FNMA	)

SELECT COUNT(LoanNumber), sum(cast(FirstPrincipalBalance as money)), DelinquencyIndicator
FROM QUNION
group by DelinquencyIndicator

