WITH PHH_Serviced as (
SELECT LOAN.LOAN_NBR_SERVICER AS LoanNumber, Cast(LOAN.PRIN_BALANCE_CURR as money) AS UPB, (LOAN.DATA_ASOF_DATE) AS DataDate
FROM PHH.Loan INNER JOIN PHH.Property ON PHH.Loan.LOAN_NBR_SERVICER = PROPERTY.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = PROPERTY.DATA_ASOF_DATE
LEFT JOIN PHH.Foreclosure ON PROPERTY.LOAN_NBR_SERVICER = Foreclosure.LOAN_NBR_SERVICER AND Property.DATA_ASOF_DATE = Foreclosure.DATA_ASOF_DATE
WHERE PROPERTY.PROP_STATE = 'CA' AND loan.DATA_ASOF_DATE = '2022-01-04'and Cast(PRIN_BALANCE_CURR as money) > 1 and Foreclosure.FCL_STATUS IN ('A')),

LoanCare_Serviced as (
SELECT loan.loannumber AS LoanNumber, Cast(loan.firstprincipalbalance as money) as UPB,Loan.MspLastRunDate as DataDate
from loancare.loan inner join loancare.property on loan.loannumber = property.LoanNumber and loan.MspLastRunDate = property.MspLastRunDate
where PropertyAlphaStateCode = 'CA' AND loan.MspLastRunDate = '2022-01-04' and Cast(FirstPrincipalBalance as money) > 1 AND LOAN.ForeclosureStatusCode IN ('A')),

ALL_SERVICED AS (
SELECT * FROM PHH_Serviced
UNION
SELECT * FROM LoanCare_Serviced),

All_SUMS AS (
select LoanNumber, min(UPB) AS UPB, MAX(DataDate) as DataDate
from ALL_SERVICED
group by LoanNumber),

LC_MODS AS (
SELECT loan.loannumber AS LoanNumber, Cast(loan.firstprincipalbalance as money) as UPB,Loan.MspLastRunDate as DataDate, Cast(LnModDate as date) AS LoanModDate, ModInfoBeforePiPmtAmount as BEFOREPNI, 
ModInfoAfterPiPmtAmount AS AFTERPNI, ModInfoBeforeMatureDate AS PRIORMAT, ModInfoAfterMatureDate AS CURRENTMAT, ModInfoBeforeInterestRate as BeforeAI, ModInfoAfterInterestRate as AfterAI
from loancare.loan inner join loancare.property on loan.loannumber = property.LoanNumber and loan.MspLastRunDate = property.MspLastRunDate
inner join LoanCare.Modification on Property.LoanNumber = Modification.LoanNumber and property.MspLastRunDate = Modification.MspLastRunDate
inner join loancare.LoanModification on Modification.LoanNumber = LoanModification.LoanNumber and Modification.MspLastRunDate = Modification.MspLastRunDate
WHERE Cast(firstprincipalbalance as money) > 1 and CAST(ModInfoBeforePiPmtAmount AS MONEY) > 0 and Loan.MspLastRunDate > '2021-12-01'),

PHH_MODS AS (
SELECT LOAN.LOAN_NBR_SERVICER AS LoanNumber, Cast(LOAN.PRIN_BALANCE_CURR as money) AS UPB, (LOAN.DATA_ASOF_DATE) AS DataDate, Cast(MOD_TRIAL_END_DATE as date) as LoanModDate, MOD_INFO_BEFORE_PI_PMT_AMOUNT as BEFOREPNI, 
MOD_INFO_AFTER_PI_PMT_AMOUNT as AFTERPNI, MOD_INFO_BEFORE_MATURE_DATE AS PRIORMAT, MOD_INFO_AFTER_MATURE_DATE AS CURRENTMAT, MOD_INFO_BEFORE_INTEREST_RATE as BeforeAI, MOD_INFO_AFTER_INTEREST_RATE as AfterAI
FROM PHH.Loan INNER JOIN PHH.Property ON PHH.Loan.LOAN_NBR_SERVICER = PROPERTY.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = PROPERTY.DATA_ASOF_DATE
INNER JOIN PHH.Modification ON Property.LOAN_NBR_SERVICER = Modification.LOAN_NBR_SERVICER AND PROPERTY.DATA_ASOF_DATE = Modification.DATA_ASOF_DATE
where cast(prin_balance_curr as money) > 1 AND caST(MOD_INFO_BEFORE_PI_PMT_AMOUNT AS MONEY) > 0 and loan.DATA_ASOF_DATE > '2021-12-01'),

ALL_MODS AS (
SELECT * FROM LC_MODS
WHERE LC_MODS.DataDate = (DATEADD(DAY, 1,LoanModDate))
UNION
SELECT * FROM PHH_MODS
where PHH_MODS.DataDate = (DATEADD(day, 1, LoanModDate)))


SELECT All_SUMS.LoanNumber, All_SUMS.UPB, LoanModDate, ALL_MODS.DataDate, BEFOREPNI, AFTERPNI, PRIORMAT, CURRENTMAT, BeforeAI, AfterAI
FROM All_SUMS INNER JOIN ALL_MODS ON All_SUMS.LoanNumber = ALL_MODS.LoanNumber