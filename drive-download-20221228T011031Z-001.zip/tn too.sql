WITH LC_SERVICED AS (
SELECT loan.loannumber AS LoanNumber, Cast(loan.firstprincipalbalance as money) as UPB, Loan.MspLastRunDate as DataDate, PropertyAlphaStateCode
from loancare.loan inner join loancare.property on loan.loannumber = property.LoanNumber and loan.MspLastRunDate = property.MspLastRunDate
left join loancare.Foreclosure on Property.LoanNumber = Foreclosure.LoanNumber and Property.MspLastRunDate = Foreclosure.MspLastRunDate
where PropertyAlphaStateCode = 'WA' AND loan.MspLastRunDate >= '2021-03-31'
),

DMI_Serviced as (
SELECT (DAILYMASTERFIELDSLOAN.LoanNumber) AS LoanNumber, Cast(DAILYMASTERFIELDSLOAN.FirstPrincipalBalance as money) AS UPB, DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE AS DataDate, PropertyAlphaStateCode
FROM DMI.DailyMasterFieldsLoan INNER JOIN DMI.DailyMasterFieldsProperty ON DMI.DAILYMASTERFIELDSLOAN.LoanNumber = DAILYMASTERFIELDSPROPERTY.LoanNumber AND 
DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE = DAILYMASTERFIELDSPROPERTY.MSPLASTRUNDATE
LEFT JOIN DMI.DailyMasterFieldsForeclosure ON DAILYMASTERFIELDSPROPERTY.LoanNumber = DailyMasterFieldsForeclosure.LoanNumber AND DAILYMASTERFIELDSPROPERTY.MSPLASTRUNDATE = DailymasterFieldsForeclosure.MSPLASTRUNDATE
WHERE DAILYMASTERFIELDSPROPERTY.PropertyAlphaStateCode = 'WA' AND DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE = '2021-03-31'),

PHH_Serviced as (
SELECT lOAN.LOAN_NBR_SERVICER as LoanNumber, Cast(LOAN.PRIN_BALANCE_CURR as money) AS UPB, (LOAN.DATA_ASOF_DATE) AS DataDate, LOAN.LOAN_NBR_PRIOR_SRVCR
FROM PHH.Loan INNER JOIN PHH.Property ON PHH.Loan.LOAN_NBR_SERVICER = PROPERTY.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = PROPERTY.DATA_ASOF_DATE
WHERE PROPERTY.PROP_STATE = 'WA' AND loan.DATA_ASOF_DATE >= '2021-03-31' ),

PHH_Serviced2 as (
SELECT lOAN.LOAN_NBR_SERVICER as LoanNumber, Cast(LOAN.PRIN_BALANCE_CURR as money) AS UPB, (LOAN.DATA_ASOF_DATE) AS DataDate, PROP_STATE
FROM PHH.Loan INNER JOIN PHH.Property ON PHH.Loan.LOAN_NBR_SERVICER = PROPERTY.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = PROPERTY.DATA_ASOF_DATE
WHERE PROPERTY.PROP_STATE = 'WA' AND loan.DATA_ASOF_DATE >= '2021-03-31'),

PHH_Override as (
select DMI_SERVICED.LoanNumber, DMI_Serviced.UPB, DMI_Serviced.DataDate, DMI_SERVICED.PropertyAlphaStateCode
from DMI_Serviced left join PHH_Serviced on DMI_Serviced.LoanNumber = PHH_Serviced.LOAN_NBR_PRIOR_SRVCR
WHERE PHH_Serviced.LoanNumber IS NULL),


ALLP AS (SELECT * FROM LC_SERVICED
UNION
SELECT * FROM PHH_Override
UNION 
SELECT * FROM PHH_Serviced2),


BIG_UNION AS (
SELECT L.LoanNumber, concat(b.MortgagorFirstName, ' ', b.MortgagorLastName) as BorrowerName, CONCAT(B.BILLINGADDRESSLINE3, ' ', B.BillingAddressLine4, b.BillingCityName, b.BillingState, b.BillingZipCode) AS BORROWER_ADDRESS, 
L.ORIGINALMORTGAGEAMOUNT, FirstPrincipalBalance, L.AnnualInterestRate, L.LOANTERM, L.LOANCLOSINGDATE, 
CASE 
WHEN OccupancyCode IN ('1') 
THEN 'Owner Occupied'
when OccupancyCode in ('2')
then 'Second Home'
when OccupancyCode in ('3')
then 'Investment Property'
end as 'Occupany Type', L.ACQUISITIONDATE, ROUND((1 - ((cast(FirstPrincipalBalance as money)/cast(OriginalMortgageAmount as money)))), 4) as LOANTOVALUERATIO, MI.MiTerminationDate, MI.MIMONTHLYAMOUNT, 
CASE 
WHEN LoType IN ('1') 
THEN 'FHA'
WHEN LoType IN ('2')
THEN ('VA')
WHEN LoType IN ('3', '6')
THEN 'CONVENTIONAL'
WHEN LoType IN ('9')
THEN 'USDA'
END AS 'LoanType', PaymentInFullDate,
D.DELINQUENCYINDICATOR, L.MSPLASTRUNDATE AS DATADATE
FROM DMI.DailyMasterFieldsLoan L INNER JOIN DMI.DAILYMASTERFIELDSBORROWER B ON L.LOANNUMBER = B.LOANNUMBER AND L.MSPLASTRUNDATE = B.MSPLASTRUNDATE
INNER JOIN DMI.DAILYMASTERFIELDSPROPERTY P ON B.LOANNUMBER = P.LOANNUMBER AND B.MSPLASTRUNDATE = P.MSPLASTRUNDATE
LEFT JOIN DMI.DAILYMASTERFIELDSMORTGAGEINSURANCE MI ON P.LOANNUMBER = MI.LOANNUMBER AND P.MSPLASTRUNDATE = MI.MSPLASTRUNDATE
LEFT JOIN DMI.DAILYMASTERFIELDSDELINQUENCY D ON P.LOANNUMBER = D.LOANNUMBER AND P.MSPLASTRUNDATE = D.MSPLASTRUNDATE
LEFT JOIN DMI.DailyMasterFieldsLossMitigation LM ON P.LoanNumber = LM.LoanNumber AND P.MspLastRunDate = LM.MspLastRunDate
WHERE L.MSPLASTRUNDATE = '2021-03-31' and PropertyAlphaStateCode = 'WA'
UNION
SELECT L.LoanNumber, concat(b.MortgagorFirstName, ' ', b.MortgagorLastName) as BorrowerName, CONCAT(B.BILLINGADDRESSLINE3, ' ', B.BillingAddressLine4, b.BillingCityName, b.BillingState, b.BillingZipCode) AS BORROWER_ADDRESS, 
O.OriginalMortgageAmount,FirstPrincipalBalance, L.AnnualInterestRate, L.LoanTerm, O.LoanClosingDate, CASE 
WHEN OccupancyCode IN ('1') 
THEN 'Owner Occupied'
when OccupancyCode in ('2')
then 'Second Home'
when OccupancyCode in ('3')
then 'Investment Property'
end as 'Occupany Type', O.AcquisitionDate, ROUND((1 - ((cast(FirstPrincipalBalance as money)/cast(OriginalMortgageAmount as money)))), 4) as LOANTOVALUERATIO, MI.MiTerminationDate, MI.MiMonthlyAmount, 
CASE 
WHEN LoType IN ('1') 
THEN 'FHA'
WHEN LoType IN ('2')
THEN ('VA')
WHEN LoType IN ('3', '6')
THEN 'CONVENTIONAL'
WHEN LoType IN ('9')
THEN 'USDA'
END AS 'LoanType', PaymentInFullDate,
D.DelinquencyIndicator, L.MspLastRunDate
FROM LoanCare.Loan L INNER JOIN LoanCare.Borrower B ON L.LoanNumber = B.LoanNumber AND L.MspLastRunDate = B.MspLastRunDate
INNER JOIN LOANCARE.OriginalLoan O ON B.LoanNumber = O.LoanNumber AND B.MspLastRunDate = O.MspLastRunDate
INNER JOIN LOANCARE.Property P ON O.LoanNumber = P.LoanNumber AND O.MspLastRunDate = P.MspLastRunDate
LEFT JOIN LOANCARE.MortgageInsurance MI ON P.LoanNumber = MI.LoanNumber AND P.MspLastRunDate = MI.MspLastRunDate
LEFT JOIN LOANCARE.Delinquency D ON P.LoanNumber = D.LoanNumber AND P.MspLastRunDate = D.MspLastRunDate
LEFT JOIN LOANCARE.Forbearance LM  ON P.LoanNumber = LM.LoanNumber AND P.MspLastRunDate = LM.MspLastRunDate
WHERE L.MspLastRunDate = '2021-03-31' AND PropertyAlphaStateCode = 'WA'
UNION
SELECT L.LOAN_NBR_SERVICER, CONCAT(B.MORTGAGOR_FIRST_NAME, ' ', B.MORTGAGOR_LAST_NAME) AS BorrowerName, CONCAT(B.BILLING_ADDRESS_LINE_3, B.BILLING_ADDRESS_LINE_4, B.BILLING_CITY_NAME, B.BILLING_CITY_STATE, B.BILLING_ZIP_CODE) AS BORROWER_ADDRESS,
L.PRIN_BALANCE_ORIG, PRIN_BALANCE_CURR, L.INT_RATE, L.TERM, L.LOAN_CLOSING_DATE, L.OCCUP_CURR, L.ACQUISITION_DATE, ROUND((1 - ((cast(PRIN_BALANCE_CURR as money)/cast(PRIN_BALANCE_ORIG as money)))), 4) as LOANTOVALUERATIO, MI.MI_TERMINATION_DATE, MI.MI_MONTHLY_AMOUNT, 
L.LOAN_TYPE, PAYOFF_DATE, D.DELINQUENCY_INDICATOR, L.DATA_ASOF_DATE
FROM PHH.Loan L INNER JOIN PHH.Borrower B ON L.LOAN_NBR_SERVICER = B.LOAN_NBR_SERVICER AND L.DATA_ASOF_DATE = B.DATA_ASOF_DATE
inner join PHH.PROPERTY P ON B.LOAN_NBR_SERVICER = P.LOAN_NBR_SERVICER AND B.DATA_ASOF_DATE = P.DATA_ASOF_DATE
LEFT JOIN PHH.MortgageInsurance MI ON P.LOAN_NBR_SERVICER = MI.LOAN_NBR_SERVICER AND P.DATA_ASOF_DATE = MI.DATA_ASOF_DATE
LEFT JOIN PHH.Delinquency D ON P.LOAN_NBR_SERVICER = D.LOAN_NBR_SERVICER AND P.DATA_ASOF_DATE = D.DATA_ASOF_DATE
LEFT JOIN PHH.Forbearance LM ON L.LOAN_NBR_SERVICER = LM.LOAN_NBR_SERVICER AND L.DATA_ASOF_DATE = LM.DATA_ASOF_DATE
WHERE L.DATA_ASOF_DATE = '2021-03-31' AND PROP_STATE = 'WA')


SELECT BU.*, AP.PropertyAlphaStateCode
from BIG_UNION BU INNER JOIN ALLP AP ON BU.LoanNumber = AP.LoanNumber AND BU.DATADATE = AP.DATADATE
ORDER BY 17 ASC