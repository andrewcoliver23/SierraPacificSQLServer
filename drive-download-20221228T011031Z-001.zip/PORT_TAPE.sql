WITH LC_TAPE AS (
select Loan.LoanNumber, MortgagorLastName, AnnualInterestRate, FirstPrincipalBalance, NextPaymentDueDate, InvestorId
from loancare.Loan inner join loancare.Borrower on loan.LoanNumber=Borrower.LoanNumber and loan.MspLastRunDate = Borrower.MspLastRunDate
where Loan.MspLastRunDate = '2022-05-31'),

PHH_TAPE AS (
select Loan.LOAN_NBR_SERVICER, MORTGAGOR_LAST_NAME, INT_RATE, PRIN_BALANCE_CURR, PMT_DUE_DATE_NEXT, INV_CODE
from PHH.Loan inner join PHH.Borrower on loan.LOAN_NBR_SERVICER=Borrower.LOAN_NBR_SERVICER and loan.DATA_ASOF_DATE = Borrower.DATA_ASOF_DATE
where Loan.DATA_ASOF_DATE = '2022-05-31')

SELECT * FROM LC_TAPE
UNION
SELECT * FROM PHH_TAPE;