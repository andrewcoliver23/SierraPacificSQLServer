WITH FUNDED AS (
SELECT
LoanNumber, FundingDate, LoanAmount, PropertyState, SubservicerID, DirectBoardingToSubservicer

FROM dbo.MWSLOS
WHERE FundingDate between '2022-09-01' and '2022-09-15' AND CHANNEL <> 'B')

SELECT COUNT(LoanNumber), SUM(LoanAmount)
from funded