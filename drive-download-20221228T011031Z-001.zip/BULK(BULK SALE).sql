bulk insert dbo.Sale
FROM 'C:\Users\andrew.oliver\OneDrive - Sierra Pacific Mortgage\Documents\SQL Server Management Studio\BULK_SALE.csv'
WITH 
(
FORMAT = 'CSV',
FIRSTROW = 2)

GO