WITH LC_SERVICED AS (
SELECT loan.loannumber AS LoanNumber, MIN(Cast(loan.firstprincipalbalance as money)) as UPB, MAX(Loan.MspLastRunDate) as DataDate
from loancare.loan inner join loancare.property on loan.loannumber = property.LoanNumber and loan.MspLastRunDate = property.MspLastRunDate
left join loancare.Foreclosure on Property.LoanNumber = Foreclosure.LoanNumber and Property.MspLastRunDate = Foreclosure.MspLastRunDate
where PropertyAlphaStateCode = 'TN' AND loan.MspLastRunDate >= '2020-06-01' and loan.msplastrundate <= '2022-07-29' 
GROUP BY LOAN.LoanNumber),

DMI_Serviced as (
SELECT (DAILYMASTERFIELDSLOAN.LoanNumber) AS LoanNumber, MIN(Cast(DAILYMASTERFIELDSLOAN.FirstPrincipalBalance as money)) AS UPB, MAX(DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE) AS DataDate
FROM DMI.DailyMasterFieldsLoan INNER JOIN DMI.DailyMasterFieldsProperty ON DMI.DAILYMASTERFIELDSLOAN.LoanNumber = DAILYMASTERFIELDSPROPERTY.LoanNumber AND 
DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE = DAILYMASTERFIELDSPROPERTY.MSPLASTRUNDATE
LEFT JOIN DMI.DailyMasterFieldsForeclosure ON DAILYMASTERFIELDSPROPERTY.LoanNumber = DailyMasterFieldsForeclosure.LoanNumber AND DAILYMASTERFIELDSPROPERTY.MSPLASTRUNDATE = DailymasterFieldsForeclosure.MSPLASTRUNDATE
WHERE DAILYMASTERFIELDSPROPERTY.PropertyAlphaStateCode = 'TN' AND DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE >= '2020-06-01'and dailymasterfieldsloan.msplastrundate <= '2021-11-30' 
GROUP BY DailyMasterFieldsLoan.LOANNUMBER),

PHH_Serviced as (
SELECT lOAN.LOAN_NBR_SERVICER as LoanNumber, MIN(Cast(LOAN.PRIN_BALANCE_CURR as money)) AS UPB, MAX((LOAN.DATA_ASOF_DATE)) AS DataDate, LOAN.LOAN_NBR_PRIOR_SRVCR
FROM PHH.Loan INNER JOIN PHH.Property ON PHH.Loan.LOAN_NBR_SERVICER = PROPERTY.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = PROPERTY.DATA_ASOF_DATE
WHERE PROPERTY.PROP_STATE = 'TN' AND loan.DATA_ASOF_DATE >= '2021-12-01' AND loan.DATA_ASOF_DATE <= '2022-7-30'
GROUP BY LOAN_NBR_PRIOR_SRVCR, loan.LOAN_NBR_SERVICER),

PHH_Serviced2 as (
SELECT lOAN.LOAN_NBR_SERVICER as LoanNumber, MIN(Cast(LOAN.PRIN_BALANCE_CURR as money)) AS UPB, MAX((LOAN.DATA_ASOF_DATE)) AS DataDate
FROM PHH.Loan INNER JOIN PHH.Property ON PHH.Loan.LOAN_NBR_SERVICER = PROPERTY.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = PROPERTY.DATA_ASOF_DATE
WHERE PROPERTY.PROP_STATE = 'TN' AND loan.DATA_ASOF_DATE >= '2021-12-01' AND loan.DATA_ASOF_DATE <= '2022-7-30' 
GROUP BY LOAN_NBR_PRIOR_SRVCR, loan.LOAN_NBR_SERVICER),

PHH_Override as (
select DMI_SERVICED.LoanNumber, DMI_Serviced.UPB, DMI_Serviced.DataDate
from DMI_Serviced left join PHH_Serviced on DMI_Serviced.LoanNumber = PHH_Serviced.LOAN_NBR_PRIOR_SRVCR
WHERE PHH_Serviced.LoanNumber IS NULL),

-- PHH OVERRIDE IS USED SO AS TO NOT OVERLAP LOANS THAT WERE ORIGINALLY WITH DMI AND TRANSFERRED TO PHH


ALLP AS (SELECT * FROM LC_SERVICED
UNION
SELECT * FROM PHH_Override
UNION 
SELECT * FROM PHH_Serviced2),

ALLP_SUMMED AS (SELECT LoanNumber, MIN(UPB) AS UPB, MAX(DATADATE) AS DATADATE
FROM ALLP
GROUP BY LoanNumber
),

BIG_UNION AS (
SELECT L.LoanNumber, OldLoanNumberFormatted, concat(b.MortgagorFirstName, ' ', b.MortgagorLastName) as BorrowerName, CONCAT(B.BILLINGADDRESSLINE3, ' ', B.BillingAddressLine4, b.BillingCityName, b.BillingState, b.BillingZipCode) AS BORROWER_ADDRESS, 
L.ORIGINALMORTGAGEAMOUNT, FirstPrincipalBalance, L.AnnualInterestRate, L.LOANTERM, L.LOANCLOSINGDATE, 
CASE 
WHEN OccupancyCode IN ('1') 
THEN 'Owner Occupied'
when OccupancyCode in ('2')
then 'Second Home'
when OccupancyCode in ('3')
then 'Investment Property'
end as 'Occupany Type', L.ACQUISITIONDATE, ROUND((1 - ((cast(FirstPrincipalBalance as money)/cast(OriginalMortgageAmount as money)))), 4) as LOANTOVALUERATIO, MI.MiTerminationDate, MI.MIMONTHLYAMOUNT, MI.MiCancellationDate, EscrowedIndicator,
CASE 
WHEN LoType IN ('1') 
THEN 'FHA'
WHEN LoType IN ('2')
THEN ('VA')
WHEN LoType IN ('3', '6')
THEN 'CONVENTIONAL'
WHEN LoType IN ('9')
THEN 'USDA'
END AS 'LoanType', PaymentInFullDate,
D.DELINQUENCYINDICATOR,L.MSPLASTRUNDATE AS DATADATE
FROM DMI.DailyMasterFieldsLoan L INNER JOIN DMI.DAILYMASTERFIELDSBORROWER B ON L.LOANNUMBER = B.LOANNUMBER AND L.MSPLASTRUNDATE = B.MSPLASTRUNDATE
INNER JOIN DMI.DAILYMASTERFIELDSPROPERTY P ON B.LOANNUMBER = P.LOANNUMBER AND B.MSPLASTRUNDATE = P.MSPLASTRUNDATE
LEFT JOIN DMI.DAILYMASTERFIELDSMORTGAGEINSURANCE MI ON P.LOANNUMBER = MI.LOANNUMBER AND P.MSPLASTRUNDATE = MI.MSPLASTRUNDATE
LEFT JOIN DMI.DAILYMASTERFIELDSDELINQUENCY D ON P.LOANNUMBER = D.LOANNUMBER AND P.MSPLASTRUNDATE = D.MSPLASTRUNDATE
LEFT JOIN DMI.DailyMasterFieldsLossMitigation LM ON P.LoanNumber = LM.LoanNumber AND P.MspLastRunDate = LM.MspLastRunDate
WHERE L.MSPLASTRUNDATE BETWEEN '2020-06-01' AND '2022-07-30' and ((cast(PaymentInFullDate as date) > '2020-06-01' OR CAST(PAYMENTINFULLDATE AS DATE) IN (' ')))
UNION
SELECT L.LoanNumber, OldLoanNumberFormatted, concat(b.MortgagorFirstName, ' ', b.MortgagorLastName) as BorrowerName, CONCAT(B.BILLINGADDRESSLINE3, ' ', B.BillingAddressLine4, b.BillingCityName, b.BillingState, b.BillingZipCode) AS BORROWER_ADDRESS, 
O.OriginalMortgageAmount,FirstPrincipalBalance, L.AnnualInterestRate, L.LoanTerm, O.LoanClosingDate, CASE 
WHEN OccupancyCode IN ('1') 
THEN 'Owner Occupied'
when OccupancyCode in ('2')
then 'Second Home'
when OccupancyCode in ('3')
then 'Investment Property'
end as 'Occupany Type', O.AcquisitionDate, ROUND((1 - ((cast(FirstPrincipalBalance as money)/cast(OriginalMortgageAmount as money)))), 4) as LOANTOVALUERATIO, MI.MiTerminationDate, MI.MiMonthlyAmount, MI.MiCancellationDate, EscrowedIndicator,
CASE 
WHEN LoType IN ('1') 
THEN 'FHA'
WHEN LoType IN ('2')
THEN ('VA')
WHEN LoType IN ('3', '6')
THEN 'CONVENTIONAL'
WHEN LoType IN ('9')
THEN 'USDA'
END AS 'LoanType', PaymentInFullDate,
D.DelinquencyIndicator, L.MspLastRunDate
FROM LoanCare.Loan L INNER JOIN LoanCare.Borrower B ON L.LoanNumber = B.LoanNumber AND L.MspLastRunDate = B.MspLastRunDate
INNER JOIN LOANCARE.OriginalLoan O ON B.LoanNumber = O.LoanNumber AND B.MspLastRunDate = O.MspLastRunDate
INNER JOIN LOANCARE.Property P ON O.LoanNumber = P.LoanNumber AND O.MspLastRunDate = P.MspLastRunDate
LEFT JOIN LOANCARE.MortgageInsurance MI ON P.LoanNumber = MI.LoanNumber AND P.MspLastRunDate = MI.MspLastRunDate
LEFT JOIN LOANCARE.Delinquency D ON P.LoanNumber = D.LoanNumber AND P.MspLastRunDate = D.MspLastRunDate
LEFT JOIN LOANCARE.Forbearance LM  ON P.LoanNumber = LM.LoanNumber AND P.MspLastRunDate = LM.MspLastRunDate
WHERE L.MspLastRunDate BETWEEN '2020-06-01' AND '2022-07-30' and ((cast(PaymentInFullDate as date) > '2020-06-01' OR CAST(PaymentInFullDate AS DATE) IN (' ')))
UNION
SELECT L.LOAN_NBR_SERVICER, LOAN_NBR_OTHERFormatted, CONCAT(B.MORTGAGOR_FIRST_NAME, ' ', B.MORTGAGOR_LAST_NAME) AS BorrowerName, CONCAT(B.BILLING_ADDRESS_LINE_3, B.BILLING_ADDRESS_LINE_4, B.BILLING_CITY_NAME, B.BILLING_CITY_STATE, B.BILLING_ZIP_CODE) AS BORROWER_ADDRESS,
L.PRIN_BALANCE_ORIG, PRIN_BALANCE_CURR, L.INT_RATE, L.TERM, L.LOAN_CLOSING_DATE, L.OCCUP_CURR, L.ACQUISITION_DATE, ROUND((1 - ((cast(PRIN_BALANCE_CURR as money)/cast(PRIN_BALANCE_ORIG as money)))), 4) as LOANTOVALUERATIO, MI.MI_TERMINATION_DATE, MI.MI_MONTHLY_AMOUNT, MI.MI_CANCELLED_DATE, ESCROWED_INDICATOR,
L.LOAN_TYPE, PAYOFF_DATE, D.DELINQUENCY_INDICATOR, L.DATA_ASOF_DATE
FROM PHH.Loan L INNER JOIN PHH.Borrower B ON L.LOAN_NBR_SERVICER = B.LOAN_NBR_SERVICER AND L.DATA_ASOF_DATE = B.DATA_ASOF_DATE
LEFT JOIN PHH.MortgageInsurance MI ON B.LOAN_NBR_SERVICER = MI.LOAN_NBR_SERVICER AND B.DATA_ASOF_DATE = MI.DATA_ASOF_DATE
LEFT JOIN PHH.Delinquency D ON B.LOAN_NBR_SERVICER = D.LOAN_NBR_SERVICER AND B.DATA_ASOF_DATE = D.DATA_ASOF_DATE
LEFT JOIN PHH.Forbearance LM ON L.LOAN_NBR_SERVICER = LM.LOAN_NBR_SERVICER AND L.DATA_ASOF_DATE = LM.DATA_ASOF_DATE
WHERE L.DATA_ASOF_DATE BETWEEN '2020-06-01' AND '2022-07-30' AND ((cast(PAYOFF_DATE as date) > '2020-06-01' OR CAST(PAYOFF_DATE AS DATE) IN (' ')))),

FBUNION AS (
SELECT F.LoanNumber, F.MspLastRunDate, F.FpOrigBeginDate, F.FpOrigPlanEndDate, DATEDIFF(DD, CAST(F.FPORIGBEGINDATE AS DATE), CAST(F.FpOrigPlanEndDate AS DATE)) as DaysInForb, FCL.FcStatusCode
FROM LOANCARE.Forbearance f 
LEFT JOIN LoanCare.Foreclosure fcl ON f.LoanNumber = fcl.LoanNumber and f.MspLastRunDate = f.MspLastRunDate
where f.MspLastRunDate between '2020-06-01' and '2022-07-30'
UNION
SELECT f.Loan_nbr_servicer, f.DATA_ASOF_DATE, F.FP_ORIG_BEGIN_DATE, F.FP_ORIG_PLAN_END_DATE, DATEDIFF(DD, CAST(F.FP_ORIG_BEGIN_DATE AS DATE), CAST(F.FP_ORIG_PLAN_END_DATE AS DATE)) as DaysInForb, FCL_STATUS
FROM PHH.Forbearance f
left join phh.Foreclosure fcl on f.LOAN_NBR_SERVICER = fcl.LOAN_NBR_SERVICER and f.DATA_ASOF_DATE = fcl.DATA_ASOF_DATE
where f.DATA_ASOF_DATE between '2020-06-01' and '2022-07-30')



SELECT BU.*, FB.FpOrigBeginDate, FB.FpOrigPlanEndDate, DaysInForb, FcStatusCode
from BIG_UNION BU INNER JOIN ALLP_SUMMED AP ON BU.LoanNumber = AP.LoanNumber AND BU.DATADATE = AP.DATADATE
LEFT JOIN FBUNION FB ON BU.LoanNumber = FB.LoanNumber and bu.DATADATE = fb.MspLastRunDate
ORDER BY 17 ASC