WITH LC_VINTAGE AS (
SELECT LoanCare.Loan.MspLastRunDate, LoanCare.Loan.LoanNumber, CAST(FirstPrincipalBalance AS MONEY) AS FirstPrincipalBalance, LoanCare.Loan.LoanReoStatusCode, LoanCare.Loan.PaymentInFullStopCode, LoanClosingDate as FundingDate,
LoanCare.Property.PropertyAlphaStateCode as PropertyState, LoanCare.Loan.InvestorId, LoanCare.Loan.ForeclosureStatusCode, LoanCare.Loan.HiType, LoanCare.Loan.LoType
FROM LoanCare.Loan INNER JOIN LoanCare.Property ON LoanCare.Loan.MspLastRunDate = LoanCare.Property.MspLastRunDate AND LoanCare.Loan.LoanNumber = LoanCare.Property.LoanNumber
INNER JOIN LOANCARE.OriginalLoan ON Property.LoanNumber = OriginalLoan.LoanNumber and Property.MspLastRunDate = OriginalLoan.MspLastRunDate
WHERE Loan.MspLastRunDate = '2022-03-31' AND CAST(FirstPrincipalBalance AS MONEY) > 1 AND LoanCare.Loan.LoanReoStatusCode <> 'A' AND LoanCare.Loan.PaymentInFullStopCode <> '1' AND LoanCare.Loan.InvestorId <> 'ACT'),

PHH_VINTAGE AS (
SELECT LOAN.DATA_ASOF_DATE as MspLastRundate, LOAN.LOAN_NBR_SERVICER as LoanNumber, Cast(PRIN_BALANCE_CURR AS MONEY) AS FirstPrincipalBalance, LOAN.LOAN_REO_STATUS_CODE as LoanReoStatuscode, 
LOAN.PAYOFF_TYPE,LOAN_CLOSING_DATE as FundingDate, PHH.Property.PROP_STATE as PropertyState, LOAN.INV_CODE AS InvestorId, 
PHH.Foreclosure.FCL_STATUS as ForeclosureStatusCode, LOAN.LIEN_POSITION as HiType, LOAN.LOAN_TYPE as LoType
FROM PHH.Loan INNER JOIN PHH.Property ON LOAN.DATA_ASOF_DATE = Property.DATA_ASOF_DATE AND LOAN.LOAN_NBR_SERVICER = Property.LOAN_NBR_SERVICER 
LEFT JOIN PHH.Foreclosure ON PHH.Property.DATA_ASOF_DATE = PHH.Foreclosure.DATA_ASOF_DATE AND PHH.Property.LOAN_NBR_SERVICER = PHH.Foreclosure.LOAN_NBR_SERVICER
WHERE LOAN.DATA_ASOF_DATE= '2022-06-30' AND Cast(PRIN_BALANCE_CURR AS money) > 1 AND LOAN.LOAN_REO_STATUS_CODE<> 'A'  AND LOAN.INV_CODE Not In ('1S1','47Y','ACT','4C9','30M'))

select * from LC_VINTAGE
UNION
select * from PHH_VINTAGE



