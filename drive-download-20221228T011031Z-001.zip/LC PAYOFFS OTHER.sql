WITH LC_PAYOFF AS (
SELECT LoanNumber, PaymentInFullDate
FROM LoanCare.Loan 
WHERE Cast(PaymentInFullDate as date) BETWEEN '2022-04-01' AND '2022-06-30'),

LC_MAX AS (
SELECT L.LoanNumber, Cast(FirstPrincipalBalance as money) as UPB, L.MspLastRunDate, T.PaymentInFullDate, InvestorId
FROM LoanCare.Loan L INNER JOIN LC_PAYOFF T ON L.LoanNumber = T.LoanNumber
WHERE L.MspLastRunDate between dateadd(dd, -7, T.PaymentInFullDate) and T.PaymentInFullDate),

LC_TOTALS AS (
SELECT LoanNumber, MAX(MspLastRunDate) as DataDate
from LC_MAX 
Where UPB > 0
GROUP BY LoanNumber
),

LC_ALL AS (
SELECT t.LoanNumber, T.DataDate, m.UPB, m.PaymentInFullDate, InvestorId
FROM LC_TOTALS T INNER JOIN LC_MAX M ON T.LoanNumber = M.LoanNumber AND T.DataDate = M.MspLastRunDate
Group by T.LoanNumber, T.DataDate, M.UPB, M.PaymentInFullDate, InvestorId
),

PAYOFFS AS (
SELECT * FROM LC_ALL)

SELECT IIf([InvestorID] In ('4EF','4EG', '47V', '47W', '47X'),'FNMA',IIf([InvestorID] in ('5AK', '30J'),'FHLMC',IIF([InvestorID] in ('6BV', 'XBV'), 'GNMA', 'Others')))
AS Investor, COUNT(LoanNumber) as LoansPIF, SUM(UPB) AS UPB_PIF, MIN(PaymentInFullDate) as Start_Range ,MAX(PaymentInFullDate) as End_Range
FROM PAYOFFS
where upb > 0.01 AND InvestorId NOT IN ('ACT')
group by IIf([InvestorID] In ('4EF','4EG', '47V', '47W', '47X'),'FNMA',IIf([InvestorID] in ('5AK', '30J'),'FHLMC',IIF([InvestorID] in ('6BV', 'XBV'), 'GNMA', 'Others')))