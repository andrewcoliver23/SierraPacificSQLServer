SELECT 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 4
THEN 'D120'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) >= 5
THEN 'D150'
ELSE 'CURRENT'
END AS 'Del',  SUM(cast(FirstPrincipalBalance as money)) as UPB, COUNT(Loan.LoanNumber) as #
FROM LoanCare.Loan INNER JOIN LOANCARE.Delinquency ON LOAN.LoanNumber = Delinquency.LoanNumber AND LOAN.MspLastRunDate = Delinquency.MspLastRunDate
WHERE LOAN.MspLastRunDate = '2022-11-30' AND CAST(FirstPrincipalBalance AS MONEY) >1 AND Loan.InvestorId <> 'ACT' AND Loan.LoanReoStatusCode <> 'A'	AND loan.LoanNumber not in ('0061820908', '0027890193')
GROUP BY CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 4
THEN 'D120'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) >= 5
THEN 'D150'
ELSE 'CURRENT'
END