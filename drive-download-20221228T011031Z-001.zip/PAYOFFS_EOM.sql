WITH LC_PAYOFF AS (
SELECT LoanNumber, PaymentInFullDate
FROM LoanCare.Loan 
WHERE Cast(PaymentInFullDate as date) BETWEEN '2022-07-09' AND '2022-07-15'),

LC_MAX AS (
SELECT L.LoanNumber, Cast(FirstPrincipalBalance as money) as UPB, L.MspLastRunDate, T.PaymentInFullDate
FROM LoanCare.Loan L INNER JOIN LC_PAYOFF T ON L.LoanNumber = T.LoanNumber
WHERE L.MspLastRunDate between dateadd(dd, -7, T.PaymentInFullDate) and T.PaymentInFullDate),

LC_TOTALS AS (
SELECT LoanNumber, MAX(MspLastRunDate) as DataDate
from LC_MAX 
Where UPB > 0
GROUP BY LoanNumber
),

LC_ALL AS (
SELECT t.LoanNumber, T.DataDate, m.UPB, m.PaymentInFullDate
FROM LC_TOTALS T INNER JOIN LC_MAX M ON T.LoanNumber = M.LoanNumber AND T.DataDate = M.MspLastRunDate
Group by T.LoanNumber, T.DataDate, M.UPB, M.PaymentInFullDate
),

PHH_PAYOFF AS (
SELECT LOAN_NBR_SERVICER, PAYOFF_DATE
FROM PHH.LOAN
WHERE Cast(PAYOFF_DATE as date) BETWEEN '2022-07-09' AND '2022-07-15'),

PHH_MAX AS (
SELECT L.LOAN_NBR_SERVICER, Cast(PRIN_BALANCE_CURR as money) as UPB, L.DATA_ASOF_DATE, T.PAYOFF_DATE
FROM PHH.Loan L INNER JOIN PHH_PAYOFF T ON L.LOAN_NBR_SERVICER = T.LOAN_NBR_SERVICER
WHERE L.DATA_ASOF_DATE between dateadd(dd, -7, T.PAYOFF_DATE) and T.PAYOFF_DATE),

PHH_TOTALS AS (
SELECT M.LOAN_NBR_SERVICER, MAX(DATA_ASOF_DATE) as DataDate
from PHH_MAX M 
Where UPB > 0
GROUP BY LOAN_NBR_SERVICER),

PHH_ALL AS (
SELECT t.LOAN_NBR_SERVICER, T.DataDate, m.UPB, m.PAYOFF_DATE
FROM PHH_TOTALS T INNER JOIN PHH_MAX M ON T.LOAN_NBR_SERVICER = M.LOAN_NBR_SERVICER AND T.DataDate = M.DATA_ASOF_DATE
Group by T.LOAN_NBR_SERVICER, T.DataDate, M.UPB, M.PAYOFF_DATE
),

PAYOFFS AS (
SELECT * FROM LC_ALL
UNION
SELECT * FROM PHH_ALL)

SELECT COUNT(LoanNumber) as LoansPIF, SUM(UPB) AS UPB_PIF, MIN(PaymentInFullDate) as Start_Range ,MAX(PaymentInFullDate) as End_Range
FROM PAYOFFS
