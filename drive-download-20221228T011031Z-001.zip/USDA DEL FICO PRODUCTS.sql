WITH USDA_EOM AS (SELECT Loan.MspLastRunDate, Loan.LoanNumber, OldLoanNumber, InvestorId, FirstPrincipalBalance AS UPB, loType, 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del','LoanCare' as DataSource, LossMitTemplateName, LossMitStatusCode, FicoScore, ProductName

FROM LoanCare.Loan
INNER JOIN LoanCare.OriginalLoan ON OriginalLOAN.LoanNumber = Loan.LoanNumber AND OriginalLoan.MspLastRunDate = Loan.MspLastRunDate
LEFT JOIN LoanCare.Foreclosure ON loan.LoanNumber = Foreclosure.LoanNumber and loan.MspLastRunDate = Foreclosure.MspLastRunDate
LEFT JOIN LOANCARE.LossMitigation lm ON OriginalLoan.LoanNumber = LM.LoanNumber AND OriginalLoan.MspLastRunDate = LM.MspLastRunDate
LEFT JOIN MWSLOS M ON Loan.LoanNumber = SubServicerLoanNumber
Where LoType in ('9') AND InvestorId <> 'ACT' AND CAST(FIRSTPRINCIPALBALANCE AS MONEY) > 1 and Loan.MspLastRunDate = '2022-11-30')

select LoanNumber, Del, ProductName, FicoScore from USDA_EOM
where Del not in ('CURRENT');

WITH USDA_EOM AS (SELECT Loan.MspLastRunDate, Loan.LoanNumber, OldLoanNumber, InvestorId, FirstPrincipalBalance AS UPB, loType, 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del','LoanCare' as DataSource, LossMitTemplateName, LossMitStatusCode, FicoScore, ProductName

FROM LoanCare.Loan
INNER JOIN LoanCare.OriginalLoan ON OriginalLOAN.LoanNumber = Loan.LoanNumber AND OriginalLoan.MspLastRunDate = Loan.MspLastRunDate
LEFT JOIN LoanCare.Foreclosure ON loan.LoanNumber = Foreclosure.LoanNumber and loan.MspLastRunDate = Foreclosure.MspLastRunDate
LEFT JOIN LOANCARE.LossMitigation lm ON OriginalLoan.LoanNumber = LM.LoanNumber AND OriginalLoan.MspLastRunDate = LM.MspLastRunDate
LEFT JOIN MWSLOS M ON Loan.LoanNumber = SubServicerLoanNumber
Where LoType in ('9') AND InvestorId <> 'ACT' AND CAST(FIRSTPRINCIPALBALANCE AS MONEY) > 1 and Loan.MspLastRunDate = '2022-11-30'),

tabExpr AS 
(
    SELECT U.LoanNumber
          ,u.FicoScore
          ,Del
		  ,ProductName
    FROM USDA_EOM U    
)
    SELECT 'Delinquency',
	AVG(pvt.FicoScore) as FicoAvg
           
    FROM tabExpr
    PIVOT ( 
           count(LoanNumber)  
           FOR Del
           IN ([D030],[D060],[D090]) 
          ) AS PVT;

