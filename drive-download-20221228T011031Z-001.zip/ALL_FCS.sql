WITH DMI_Serviced as (
SELECT (DAILYMASTERFIELDSLOAN.LoanNumber) AS LoanNumber, Cast(DAILYMASTERFIELDSLOAN.FirstPrincipalBalance as money) AS UPB, (DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE) AS DataDate
FROM DMI.DailyMasterFieldsLoan INNER JOIN DMI.DailyMasterFieldsProperty ON DMI.DAILYMASTERFIELDSLOAN.LoanNumber = DAILYMASTERFIELDSPROPERTY.LoanNumber AND 
DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE = DAILYMASTERFIELDSPROPERTY.MSPLASTRUNDATE
LEFT JOIN DMI.DailyMasterFieldsForeclosure ON DAILYMASTERFIELDSPROPERTY.LoanNumber = DailyMasterFieldsForeclosure.LoanNumber AND DAILYMASTERFIELDSPROPERTY.MSPLASTRUNDATE = DailymasterFieldsForeclosure.MSPLASTRUNDATE
WHERE DAILYMASTERFIELDSPROPERTY.PropertyAlphaStateCode = 'CA' AND DAILYMASTERFIELDSLOAN.MSPLASTRUNDATE >= '2021-10-01'and dailymasterfieldsloan.msplastrundate <= '2021-12-31' 
and Cast(FirstPrincipalBalance as money) > 1 and FcStatusCode IN ('A')),

LoanCare_Serviced as (
SELECT loan.loannumber AS LoanNumber, Cast(loan.firstprincipalbalance as money) as UPB,Loan.MspLastRunDate as DataDate
from loancare.loan inner join loancare.property on loan.loannumber = property.LoanNumber and loan.MspLastRunDate = property.MspLastRunDate
where PropertyAlphaStateCode = 'CA' AND loan.MspLastRunDate >= '2021-10-01' and loan.msplastrundate <= '2021-12-31' and Cast(FirstPrincipalBalance as money) > 1 AND LOAN.ForeclosureStatusCode IN ('A')),

ALL_SERVICED AS (
SELECT * FROM DMI_Serviced
UNION
SELECT * FROM LoanCare_Serviced),

All_SUMS AS (
select LoanNumber, min(UPB) AS UPB, MAX(DataDate) as DataDate
from ALL_SERVICED
group by LoanNumber),

LC_FORBS AS 
(SELECT LoanCare.Loan.MspLastRunDate, LoanCare.Loan.LoanNumber, LoanCare.Loan.InvestorId, LoanCare.property.PropertyAlphaStateCode, LoanCare.Loan.FirstPrincipalBalance, LoanCare.Loan.NextPaymentDueDate, 
LoanCare.LossMitigation.LossMitStatusCode, LoanCare.LossMitigation.LossMitTypeCode, LoanCare.LossMitigation.LossMitTemplateName, LoanCare.LossMitigation.LossMitStatusChangeDate
FROM LoanCare.Loan INNER JOIN LoanCare.Property ON LoanCare.Loan.MspLastRunDate = LoanCare.property.MspLastRunDate AND LoanCare.Loan.LoanNumber = LoanCare.property.LoanNumber 
INNER JOIN LoanCare.LossMitigation ON LoanCare.property.MspLastRunDate = LoanCare.LossMitigation.MspLastRunDate AND LoanCare.property.LoanNumber = LoanCare.LossMitigation.LoanNumber
WHERE (cast(FirstPrincipalBalance as money) > 1 AND ((LoanCare.LossMitigation.LossMitStatusCode)='A') AND ((LoanCare.LossMitigation.LossMitTypeCode)='FBCV') 
AND ((LoanCare.LossMitigation.LossMitTemplateName) Not In ('FLXFRED','FLXFNMA'))) OR ((cast(LoanCare.Loan.FirstPrincipalBalance as money))>1) 
AND ((LoanCare.LossMitigation.LossMitStatusCode)='A') AND ((LoanCare.LossMitigation.LossMitTemplateName)='PDFORB')),

DMI_FORBS AS 
(SELECT DMI.DailyMasterFieldsLoan.MspLastRunDate, DMI.DailyMasterFieldsLoan.LoanNumber, DMI.DailyMasterFieldsLoan.InvestorId, DMI.Dailymasterfieldsproperty.PropertyAlphaStateCode, DMI.DailyMasterFieldsLoan.FirstPrincipalBalance, DMI.DailyMasterFieldsLoan.NextPaymentDueDate, 
DMI.DailymasterfieldsLossMitigation.LossMitStatusCode, DMI.DailymasterfieldsLossMitigation.LossMitTypeCode, DMI.DailymasterfieldsLossMitigation.LossMitTemplateName, DMI.DailymasterfieldsLossMitigation.LossMitStatusChangeDate
FROM DMI.DailyMasterFieldsLoan INNER JOIN DMI.DailyMasterFieldsProperty ON DMI.DailyMasterFieldsLoan.MspLastRunDate = DMI.Dailymasterfieldsproperty.MspLastRunDate AND DMI.DailyMasterFieldsLoan.LoanNumber = DMI.Dailymasterfieldsproperty.LoanNumber 
INNER JOIN DMI.DailyMasterFieldsLossMitigation ON DMI.Dailymasterfieldsproperty.MspLastRunDate = DMI.DailymasterfieldsLossMitigation.MspLastRunDate AND DMI.Dailymasterfieldsproperty.LoanNumber = DMI.DailymasterfieldsLossMitigation.LoanNumber
WHERE (cast(FirstPrincipalBalance as money) > 1 AND ((DMI.DailymasterfieldsLossMitigation.LossMitStatusCode)='A') AND ((DMI.DailymasterfieldsLossMitigation.LossMitTypeCode)='FBCV') 
AND ((DMI.DailymasterfieldsLossMitigation.LossMitTemplateName) Not In ('FLXFRED','FLXFNMA'))) OR ((cast(DMI.DailyMasterFieldsLoan.FirstPrincipalBalance as money))>1) 
AND ((DMI.DailymasterfieldsLossMitigation.LossMitStatusCode)='A') AND ((DMI.DailymasterfieldsLossMitigation.LossMitTemplateName)='PDFORB')),

ALL_FORBS AS (
SELECT * FROM LC_FORBS
UNION
SELECT * FROM DMI_FORBS)

SELECT COUNT(All_SUMS.LoanNumber) AS #, sum(all_sums.upb) as UPB
from All_SUMS INNER JOIN ALL_FORBS ON All_SUMS.LoanNumber = ALL_FORBS.LoanNumber AND All_SUMS.DataDate = DATEADD(DAY, 1, ALL_FORBS.LossMitStatusChangeDate)
