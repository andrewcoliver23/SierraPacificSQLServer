SELECT distinct(foreclosure.LoanNumber), L.LoanNumber as LoanNumber,  
CASE 
WHEN LoType IN ('1') 
THEN 'FHA'
WHEN LoType IN ('2')
THEN ('VA')
WHEN LoType IN ('3', '6')
THEN 'CONVENTIONAL'
WHEN LoType IN ('9')
THEN 'USDA'
END AS 'LoanType',
O.OldLoanNumberFormatted, concat(b.MortgagorFirstName, ' ', b.MortgagorLastName) as BorrowerName, CONCAT(B.BILLINGADDRESSLINE3, ' ', B.BillingAddressLine4, b.BillingCityName, b.BillingState, b.BillingZipCode) AS BORROWER_ADDRESS,
IIf([InvestorID] In ('4EF','4EG'),'FNMA',IIf([InvestorID] in ('5AK'),'FHLMC',IIf([InvestorID] In ('A60','ACT'),'Portfolio',IIF([InvestorID] in ('6BV', 'XBV'), 'GNMA', 'Others')))) AS Investor,
Cast(l.firstprincipalbalance as money) as UPB,  LoanClosingDate, AcquisitionDate, OriginalMortgageAmount, L.FirstPAndIAmount, FirstDueDate, NextPaymentDueDate, PaymentInFullDate, ArmIndicator, EscrowedIndicator, BankruptcyStatusCodeM, LoanLossMitStatusCode, ForeclosureStatusCode, 
FcSaleDate, DelinquencyIndicator ,L.msplastrundate as DataDate
from loancare.loan L inner join loancare.property p on l.loannumber = p.LoanNumber and l.MspLastRunDate = p.MspLastRunDate
inner join loancare.OriginalLoan O on p.LoanNumber = o.LoanNumber and p.MspLastRunDate = o.MspLastRunDate
inner JOIN LoanCare.Borrower b ON O.LoanNumber = B.LoanNumber AND O.MspLastRunDate = B.MspLastRunDate
left join loancare.Foreclosure on P.LoanNumber = Foreclosure.LoanNumber and P.MspLastRunDate = Foreclosure.MspLastRunDate
left join loancare.Delinquency D on b.LoanNumber = d.LoanNumber and b.MspLastRunDate = d.MspLastRunDate
where l.MspLastRunDate = '2022-06-30' and cast(FirstPrincipalBalance as money) > 1 and LoanReoStatusCode <> 'A'

/* 
�	Loan Type
�	Old Servicing Loan Number
�	New Servicing Loan Number
�	Borrower Last Name/First Name
�	Property Address including State
�	Investor Name (i.e.,FNMA, FHLMC, FHA, VA, OTHER)
�	New Loan Date
�	Servicing Transfer Date/Loan Boarded Date
�	Original Loan Amount
�	Current Principal Balance
�	P&I Monthly Amount
�	First Payment Due Date
�	Next Payment Due Date
�	Paid in Full Indicator/Flag
�	Paid in Full Date
�	ARM Indicator/Flag
�	Escrow Indicator/Flag
�	Delinquency Status */
