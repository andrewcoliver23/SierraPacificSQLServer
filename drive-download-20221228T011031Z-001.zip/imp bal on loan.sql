SELECT dbo.loans.loan.id, dbo.loans.loan.num, dbo.investors.invstr.id, dbo.investors.invstr.name, dbo.loans.status.type, dbo.distributions.distrib.type, Sum(dbo.distributions.distrib.amt) AS SumOfdistrib_amt1 INTO [Imp bal 10-8-2021]
FROM (dbo.transactions LEFT JOIN dbo.distributions ON dbo.transactions.trans.id = dbo.distributions.trans.id) RIGHT JOIN dbo.loans ON dbo.transactions.loan.id = dbo.loans.loan.id) LEFT JOIN dbo.investors ON dbo.loans.invstr.id = dbo.investors.invstr.id
WHERE (((dbo.loans.client.id)="spm") AND ((dbo.distributions.distrib.date)<#10/9/2021#))
GROUP BY dbo.loans.loan.id, dbo.loans.loan.num, dbo.investors.invstr.id, dbo.investors.invstr.name, dbo.loans.status.type, dbo.distributions.distrib.type
HAVING (((dbo.loans.status.type) In ("A","AS")) AND ((dbo.distributions.distrib.type)="IMP") AND ((Sum(dbo.distributions.distrib.amt))<>0))
ORDER BY dbo.loans.status.type;
