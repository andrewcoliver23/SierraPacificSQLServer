WITH LC_VINTAGE AS (
SELECT LoanCare.Loan.MspLastRunDate, LoanCare.Loan.LoanNumber, CAST(FirstPrincipalBalance AS MONEY) AS FirstPrincipalBalance, LoanCare.Loan.LoanReoStatusCode, LoanCare.Loan.PaymentInFullStopCode, LoanClosingDate as FundingDate,
LoanCare.Property.PropertyAlphaStateCode as PropertyState, LoanCare.Loan.InvestorId, LoanCare.Loan.ForeclosureStatusCode, LoanCare.Loan.HiType, LoanCare.Loan.LoType
FROM LoanCare.Loan INNER JOIN LoanCare.Property ON LoanCare.Loan.MspLastRunDate = LoanCare.Property.MspLastRunDate AND LoanCare.Loan.LoanNumber = LoanCare.Property.LoanNumber
INNER JOIN LOANCARE.OriginalLoan ON Property.LoanNumber = OriginalLoan.LoanNumber and Property.MspLastRunDate = OriginalLoan.MspLastRunDate
WHERE Loan.MspLastRunDate = '2022-09-30' AND CAST(FirstPrincipalBalance AS MONEY) > 1 AND LoanCare.Loan.LoanReoStatusCode <> 'A' AND LoanCare.Loan.PaymentInFullStopCode <> '1' AND LoanCare.Loan.InvestorId <> 'ACT'),

AVG1 AS (SELECT ((FirstPrincipalBalance)/((select aVG(FirstPrincipalBalance) from LC_VINTAGE)))*DATEDIFF(M, FundingDate, GETDATE()) AS WEIGHTED_AVG
FROM LC_VINTAGE)

SELECT AVG(WEIGHTED_AVG)
FROM AVG1