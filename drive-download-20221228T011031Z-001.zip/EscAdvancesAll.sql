WITH LoanCareEscAdvance AS ( 
SELECT LoanCare.Escrow.LoanNumber, [EscrowExpdAdvanceBalance] AS EscAdv,RecoverCorpAdvanceBalance, NonRecCorpAdvanceBalance,ThirdPartyRecoverableCaBal, (CAST(NonRecCorpAdvanceBalance AS MONEY)+CAST(EscrowExpdAdvanceBalance AS MONEY) + CAST(ThirdPartyRecoverableCaBal AS MONEY)+ 
CAST(RecoverCorpAdvanceBalance AS MONEY)) as TotalAdvance, LoanCare.Escrow.MspLastRunDate, LoanCare.Loan.InvestorId, 
IIf([InvestorID] In ('4EF','4EG'),'FNMA',IIf([InvestorID]='5AK','FHLMC',IIf([InvestorID] In ('A60','XBV'),'Portfolio', IIF([INVESTORID] IN ('ACT'), 'Interim Servicing', 'GNMA'))) 
AS Investor, Escrow.OverOrShortAmount, LoanCare.Escrow.EscrowBalance, LoanCare.Escrow.LastAnalysisDate, LoanCare.Escrow.LastAnalysisOsSpreadMonths, LoanCare.Escrow.LastAnalysisEffectiveDate, 
LoanCare.Loan.SuspenseBalance, DelinquencyIndicator, IIF([DelinquencyIndicator] = '1', '30 Days', IIF([DelinquencyIndicator] = '2', '60 Days', IIF([DelinquencyIndicator] = '3', '90 Days', 
iif([DelinquencyIndicator] = '4', '120+', 'Current')))) as DelqIndicator, NextPaymentDueDate, FirstPrincipalBalance
FROM LoanCare.Loan LEFT JOIN LoanCare.Escrow ON LoanCare.Loan.MspLastRunDate = LoanCare.Escrow.MspLastRunDate AND LoanCare.Loan.LoanNumber = LoanCare.Escrow.LoanNumber
LEFT JOIN LoanCare.CorporateAccounting ca ON LOAN.LoanNumber = CA.LoanNumber AND LOAN.MspLastRunDate =CA.MspLastRunDate
LEFT JOIN LoanCare.Delinquency ON (LoanCare.Escrow.LoanNumber = LoanCare.Delinquency.LoanNumber) AND (LoanCare.Escrow.MspLastRunDate = LoanCare.Delinquency.MspLastRunDate)
WHERE (Cast([EscrowExpdAdvanceBalance] as money) <> 0 or cast(RecoverCorpAdvanceBalance AS MONEY) <> 0 OR CAST(ThirdPartyRecoverableCaBal AS MONEY)<> 0 OR CAST(NonRecCorpAdvanceBalance AS MONEY) <> 0) 
AND ((LoanCare.Escrow.MspLastRunDate) = '2022-06-30') AND ((LoanCare.Loan.InvestorId)<>'4C9')),

PHHEscAdvance AS (
SELECT PHH.Loan.LOAN_NBR_SERVICER, Cast([ESCROW_ADVANCE_BALANCE] as money) AS [EscAdv], PHH.Loan.DATA_ASOF_DATE, PHH.Loan.INV_CODE, IIf([INV_CODE]='30J','FHLMC',IIf([INV_CODE] In ('47V','47X'),'FNMA','Portfolio')) 
AS INVESTOR, PHH.Escrow.OVER_OR_SHORT_AMOUNT, PHH.Escrow.ESCROW_BALANCE, PHH.Escrow.LAST_ANALYSIS_DATE, PHH.Escrow.LAST_ANALYSIS_OS_SPREAD_MONTHS, 
PHH.Escrow.LAST_ANALYSIS_EFFECTIVE_DATE, PHH.Loan.SUSP_BALANCE, DELINQUENCY_INDICATOR, IIF([Delinquency_Indicator] = '1', '30 Days', IIF([Delinquency_Indicator] = '2', '60 Days', IIF([Delinquency_Indicator] = '3', '90 Days', 
iif([Delinquency_Indicator] = '4', '120+', 'Current')))) as DelqIndicator
FROM PHH.Loan INNER JOIN PHH.Escrow ON PHH.Loan.DATA_ASOF_DATE = PHH.Escrow.DATA_ASOF_DATE AND PHH.Loan.LOAN_NBR_SERVICER = PHH.Escrow.LOAN_NBR_SERVICER
LEFT JOIN PHH.Delinquency ON (PHH.Escrow.LOAN_NBR_SERVICER = PHH.Delinquency.LOAN_NBR_SERVICER) AND PHH.Escrow.DATA_ASOF_DATE = PHH.Delinquency.DATA_ASOF_DATE
WHERE CAST([ESCROW_ADVANCE_BALANCE] AS MONEY)<>0 AND PHH.Loan.DATA_ASOF_DATE= '2022-06-30' AND PHH.Loan.INV_CODE <>'30M')


SELECT * FROM LoanCareEscAdvance
UNION
SELECT * FROM PHHEscAdvance
