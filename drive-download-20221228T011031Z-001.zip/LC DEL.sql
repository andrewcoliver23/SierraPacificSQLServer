SELECT 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') = 4
THEN 'D120'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') >= 5
THEN 'D150'
ELSE 'CURRENT'
END AS 'Del', COUNT(Loan.LoanNumber) as #, SUM(cast(FirstPrincipalBalance as money)) as UPB 
FROM LoanCare.Loan INNER JOIN LOANCARE.Delinquency ON LOAN.LoanNumber = Delinquency.LoanNumber AND LOAN.MspLastRunDate = Delinquency.MspLastRunDate
WHERE LOAN.MspLastRunDate = '2022-05-31' AND CAST(FirstPrincipalBalance AS MONEY) >1 AND Loan.InvestorId <> 'ACT' AND Loan.LoanReoStatusCode <> 'A'
GROUP BY CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') = 4
THEN 'D120'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, '2022-06-01') >= 5
THEN 'D150'
ELSE 'CURRENT'
END