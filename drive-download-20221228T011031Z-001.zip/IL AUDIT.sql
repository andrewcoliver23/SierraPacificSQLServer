SELECT F.*, J.* FROM LOANCARE.Foreclosure f
INNER JOIN LOANCARE.ForeclosureSteps J ON F.LoanNumber = J.LoanNumber AND F.MspLastRunDate = J.MspLastRunDate
INNER JOIN LOANCARE.Property P ON J.LoanNumber = P.LoanNumber AND J.MspLastRunDate = P.MspLastRunDate
WHERE PropertyAlphaStateCode = 'IL' AND FcStartDate IS NOT NULL AND F.MspLastRunDate > '2022-01-01' ANd StepCode = 'F30' AND cast(ActualCompletionDate as date) >= '2022-01-01'