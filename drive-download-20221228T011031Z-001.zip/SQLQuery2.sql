SELECT DISTINCT(LoanCare.Loan.LOANNUMBER) AS '#'
FROM LoanCare.Loan
WHERE LoanCare.loan.msplastrundate >= '2021-01-01' AND LoanCare.loan.msplastrundate <= '2021-12-31'