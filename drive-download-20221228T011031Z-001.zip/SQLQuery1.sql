DECLARE
@d date = '2022-12-02'

;

with  

db_loans as (SELECT dbo.MWSLOS.DirectBoardingToSubservicer, dbo.MWSLOS.LoanNumber as LoanNumber, dbo.MWSLOS.FundingDate, dbo.MWSLOS.InvestorCompanyName, dbo.MWSLOS.InvestorPurchasedDate, dbo.MWSLOS.LoanAmount AS pv, dbo.MWSLOS.PurchasePrincipalBalance, 
dbo.PurchasedLoans.PurchaseBalance, dbo.PurchasedLoans.PuchaseWireDate, dbo.MWSLOS.TransferDate, dbo.MWSLOS.LPIDate AS LPI_Date_OPS, dbo.MWSLOS.InvestorPurchaseLPI, dbo.MWSLOS.FirstPaymentDueDate, dbo.MWSLOS.InterestRate
FROM dbo.MWSLOS LEFT JOIN dbo.PurchasedLoans ON dbo.MWSLOS.LosLoanId = dbo.PurchasedLoans.PurchasedLoanNumber
WHERE dbo.MWSLOS.DirectBoardingToSubservicer='Y'),

dbo_ServicingLoan as (Select L.InvestorId, l.LoanNumber, l.LastFullPaymentDate, cast(l.AnnualInterestRate as float) as AnnualInterestRate, l.FirstPrincipalBalance, cast(l.NextPaymentDueDate as date) as NextPaymentDueDate, l.FirstPAndIAmount, o.OldLoanNumberFormatted, 
cast(l.LoanTerm as int) lt 
from LoanCare.Loan L 
INNER JOIN LoanCare.OriginalLoan O ON L.LoanNumber = O.LoanNumber AND L.MspLastRunDate = O.MspLastRunDate
WHERE l.MspLastRunDate = @d and cast(FirstPrincipalBalance as money) > 0 

union 
select 	l.INV_CODE, l.LOAN_NBR_SERVICER,l.PMT_RECEIVED_DATE_LAST, cast(l.INT_RATE as float), l.PRIN_BALANCE_CURR, cast(l.PMT_DUE_DATE_NEXT as date), l.PMT_AMT_PI, l.LOAN_NBR_OTHERFormatted, cast(l.TERM as int)
from phh.Loan l
where DATA_ASOF_DATE = @d and cast(PRIN_BALANCE_CURR as money) > 0),

initial_loan_population as (SELECT db_loans.DirectBoardingToSubservicer, dbo_ServicingLoan.InvestorID, dbo_ServicingLoan.LoanNumber, dbo_ServicingLoan.OldLoanNumberFormatted, db_loans.PurchasePrincipalBalance, dbo_ServicingLoan.FirstPAndIAmount, 
db_loans.FirstPaymentDueDate, 
dbo_ServicingLoan.NextPaymentDueDate, db_loans.InvestorPurchaseLPI, db_loans.LPI_Date_OPS, db_loans.PurchaseBalance, dbo_ServicingLoan.LastFullPaymentDate AS LPIDatesub, db_loans.TransferDate, db_loans.InterestRate, db_loans.pv, 
DateDiff(m,FirstPaymentDueDate,NextPaymentDueDate)+1 AS PMT#, db_loans.PuchaseWireDate, dbo_ServicingLoan.AnnualInterestRate/12 as rate, dbo_ServicingLoan.FirstPrincipalBalance, dbo_ServicingLoan.LastFullPaymentDate, lt
FROM db_loans LEFT JOIN dbo_ServicingLoan ON db_loans.LoanNumber = dbo_ServicingLoan.OldLoanNumberFormatted
where db_loans.DirectBoardingToSubservicer in ('Y')
),

final_initial_loan_population as (SELECT  ilp.DirectBoardingToSubservicer, ilp.InvestorID, ilp.LoanNumber, ilp.OldLoanNumberFormatted,  ilp.PurchasePrincipalBalance, ilp.FirstPrincipalBalance, ilp.FirstPAndIAmount,  
ilp.FirstPaymentDueDate, ilp.NextPaymentDueDate,  ilp.InvestorPurchaseLPI,  ilp.LPI_Date_OPS , ilp.LastFullPaymentDate AS  LPIDatesub ,  ilp.TransferDate,  ilp.InterestRate,  
ilp.pv,  ilp.PurchaseBalance,  ilp.PuchaseWireDate,  ilp.PMT#, Round((pv * ((rate * Power((1+rate), lt)/(POWER((1+rate), lt)-1)))), 2) as PeriodicPayment, lt, rate
FROM  initial_loan_population ilp 
WHERE PMT# > 1
),

schedule as (SELECT final_initial_loan_population.LoanNumber, final_initial_loan_population.InterestRate AS Int_rate, final_initial_loan_population.FirstPaymentDueDate, final_initial_loan_population.NextPaymentDueDate, final_initial_loan_population.FirstPAndIAmount AS principal_int_amt_1, 
final_initial_loan_population.pv, PeriodicPayment * PMT# AS TotalPayment ,(POWER((1+rate), PMT#)-1)/(POWER((1+rate), lt)-1) * pv as TotalPrincipal, (PeriodicPayment * PMT#) - ((POWER((1+rate), PMT#)-1)/(POWER((1+rate), lt)-1) * pv )

AS [INT Due], PeriodicPayment AS [Prin Due]
FROM final_initial_loan_population)


--SELECT [initial loan population].DirectBoardingToSubservicer, dbo_ServicingLoan.InvestorID, dbo_ServicingLoan.LoanNumber, dbo_ServicingLoan.OldLoanNumber, [initial loan population].PurchasePrincipalBalance, 
--dbo_ServicingLoan.FirstPrincipalBalance, dbo_ServicingLoan.FirstPAndIAmount, [initial loan population].FirstPaymentDueDate, dbo_ServicingLoan.NextPaymentDueDate, [initial loan population].InvestorPurchaseLPI, [initial loan population].[LPI Date OPS], 
--dbo_ServicingLoan.LastFullPaymentDate AS [LPIDate sub], [initial loan population].TransferDate, [initial loan population].InterestRate, [initial loan population].orig_loan_amt, [initial loan population].PurchaseBalance, [initial loan population].PuchaseWireDate, 
--[initial loan population].[PMT #] INTO [final intial loan population]
--FROM [initial loan population] LEFT JOIN dbo_ServicingLoan ON [initial loan population].LoanNumber = dbo_ServicingLoan.LoanNumber;


 
SELECT final_initial_loan_population.LoanNumber, final_initial_loan_population.OldLoanNumberFormatted, final_initial_loan_population.TransferDate, final_initial_loan_population.LPI_Date_OPS, final_initial_loan_population.LPIDatesub, 
final_initial_loan_population.FirstPaymentDueDate, final_initial_loan_population.NextPaymentDueDate, final_initial_loan_population.InvestorPurchaseLPI, final_initial_loan_population.PuchaseWireDate, final_initial_loan_population.pv as LoanAmount, 
final_initial_loan_population.PurchaseBalance, final_initial_loan_population.FirstPrincipalBalance, final_initial_loan_population.FirstPAndIAmount, schedule.TotalPayment, schedule.TotalPrincipal, schedule.[INT Due], schedule.[Prin Due], PMT#
FROM final_initial_loan_population LEFT JOIN schedule ON final_initial_loan_population.LoanNumber = schedule.LoanNumber
WHERE (final_initial_loan_population.NextPaymentDueDate='2022-12-01' AND final_initial_loan_population.InvestorPurchaseLPI Is Null AND DateDiff(m,final_initial_loan_population.[NextPaymentDueDate],@d)<=3)
OR (final_initial_loan_population.NextPaymentDueDate <= final_initial_loan_population.InvestorPurchaseLPI AND DateDiff(m, final_initial_loan_population.NextPaymentDueDate, @d) <=3)







