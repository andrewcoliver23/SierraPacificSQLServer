select Loan.LoanNumber, MortgagorLastName, AnnualInterestRate, FirstPrincipalBalance, NextPaymentDueDate, InvestorId
from loancare.Loan inner join loancare.Borrower on loan.LoanNumber=Borrower.LoanNumber and loan.MspLastRunDate = Borrower.MspLastRunDate
where Loan.MspLastRunDate = '2022-05-31'