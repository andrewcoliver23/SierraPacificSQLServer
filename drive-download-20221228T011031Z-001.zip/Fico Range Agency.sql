WITH new_table AS (Select
CASE
 WHEN MWSLOS.FicoScore <= 640 THEN '<=640'
 WHEN MWSLOS.FicoScore > 640 AND MWSLOS.FicoScore <= 680 THEN '>640 AND <=680'
 WHEN MWSLOS.FicoScore > 680 AND MWSLOS.FicoScore <= 720 THEN '>680 AND <=720'
 ELSE '>720'
END AS 'FICO Range', MWSLOS.LoanNumber AS 'Number', MWSLOS.LoanPurposeType AS 'LoanPurpose'
FROM MWSLOS)


SELECT new_table.[FICO Range], COUNT(new_table.Number) AS 'Total #'
FROM new_table
INNER JOIN dbo.ServicingLoan ON new_table.Number = dbo.ServicingLoan.OldLoanNumberFormatted
INNER JOIN	dbo.ServicingLossMitigation ON dbo.ServicingLoan.LoanNumber = dbo.ServicingLossMitigation.LoanNumber
WHERE dbo.ServicingLossMitigation.LossMitTemplateName = 'PDFORB' AND new_table.LoanPurpose = 'RCO' AND ((dbo.ServicingLoan.InvestorId = '4EG') OR (dbo.ServicingLoan.InvestorId = '4EF') OR (dbo.ServicingLoan.InvestorId = '5AK')
OR (dbo.ServicingLoan.InvestorId = '361') OR (dbo.ServicingLoan.InvestorId = '362') OR (dbo.ServicingLoan.InvestorId = '363') OR (dbo.ServicingLoan.InvestorId = '364'))
GROUP BY new_table.[FICO Range]
ORDER BY new_table.[FICO Range];