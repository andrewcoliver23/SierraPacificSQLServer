WITH new_table AS (Select
CASE
 WHEN MWSLOS.LoanPurposeType = 'OA' THEN 'Open Access'
 WHEN MWSLOS.LoanPurposeType = 'R&T' THEN 'Refi - No Cash Out'
 WHEN MWSLOS.LoanPurposeType = 'RCO' THEN 'Refi - Cash Out'
 WHEN MWSLOS.LoanPurposeType = 'RP' THEN 'Refi Plus'
 WHEN MWSLOS.LoanPurposeType = 'SR' THEN 'Streamline Refi'
 ELSE 'Purchase'
END AS 'Loan Purpose', MWSLOS.LoanNumber AS 'Number'
FROM MWSLOS)


SELECT new_table.[Loan Purpose], COUNT(new_table.Number) AS 'Total #'
FROM new_table
INNER JOIN dbo.ServicingLoan ON new_table.Number = dbo.ServicingLoan.OldLoanNumberFormatted
INNER JOIN	dbo.ServicingLossMitigation ON dbo.ServicingLoan.LoanNumber = dbo.ServicingLossMitigation.LoanNumber
WHERE dbo.ServicingLossMitigation.LossMitTemplateName = 'PDFORB' AND  (dbo.ServicingLoan.InvestorId = '4EG' OR dbo.ServicingLoan.InvestorId = '4EF' OR dbo.ServicingLoan.InvestorId = '5AK'
OR dbo.ServicingLoan.InvestorId = '361' OR dbo.ServicingLoan.InvestorId = '362' OR dbo.ServicingLoan.InvestorId = '363' OR dbo.ServicingLoan.InvestorId = '364')
GROUP BY new_table.[Loan Purpose]
ORDER BY 1;