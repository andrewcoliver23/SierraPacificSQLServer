WITH MSPLASTRUN AS (select '2022-09-30' as DataDate),

FHA_EOM AS (SELECT Loan.MspLastRunDate, Loan.LoanNumber, OldLoanNumber, InvestorId, FirstPrincipalBalance AS UPB, loType, 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del','LoanCare' as DataSource, LossMitTemplateName, LossMitStatusCode

FROM LoanCare.Loan
INNER JOIN LoanCare.OriginalLoan ON OriginalLOAN.LoanNumber = Loan.LoanNumber AND OriginalLoan.MspLastRunDate = Loan.MspLastRunDate
LEFT JOIN LoanCare.Foreclosure ON loan.LoanNumber = Foreclosure.LoanNumber and loan.MspLastRunDate = Foreclosure.MspLastRunDate
LEFT JOIN LOANCARE.LossMitigation lm ON OriginalLoan.LoanNumber = LM.LoanNumber AND OriginalLoan.MspLastRunDate = LM.MspLastRunDate
left join MSPLASTRUN M on Loan.MspLastRunDate = m.DataDate
Where LoType in ('1') AND InvestorId <> 'ACT' AND CAST(FIRSTPRINCIPALBALANCE AS MONEY) > 1 and Loan.MspLastRunDate = m.DataDate), 

VA_EOM AS (SELECT Loan.MspLastRunDate, Loan.LoanNumber, OldLoanNumber, InvestorId, FirstPrincipalBalance AS UPB, loType, 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del','LoanCare' as DataSource, LossMitTemplateName, LossMitStatusCode

FROM LoanCare.Loan
INNER JOIN LoanCare.OriginalLoan ON OriginalLOAN.LoanNumber = Loan.LoanNumber AND OriginalLoan.MspLastRunDate = Loan.MspLastRunDate
LEFT JOIN LoanCare.Foreclosure ON loan.LoanNumber = Foreclosure.LoanNumber and loan.MspLastRunDate = Foreclosure.MspLastRunDate
LEFT JOIN LOANCARE.LossMitigation lm ON OriginalLoan.LoanNumber = LM.LoanNumber AND OriginalLoan.MspLastRunDate = LM.MspLastRunDate
left join MSPLASTRUN M on Loan.MspLastRunDate = m.DataDate
Where LoType in ('2') AND InvestorId <> 'ACT' AND CAST(FIRSTPRINCIPALBALANCE AS MONEY) > 1 and Loan.MspLastRunDate = m.DataDate),

USDA_EOM AS (SELECT Loan.MspLastRunDate, Loan.LoanNumber, OldLoanNumber, InvestorId, FirstPrincipalBalance AS UPB, loType, 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del','LoanCare' as DataSource, LossMitTemplateName, LossMitStatusCode

FROM LoanCare.Loan
INNER JOIN LoanCare.OriginalLoan ON OriginalLOAN.LoanNumber = Loan.LoanNumber AND OriginalLoan.MspLastRunDate = Loan.MspLastRunDate
LEFT JOIN LoanCare.Foreclosure ON loan.LoanNumber = Foreclosure.LoanNumber and loan.MspLastRunDate = Foreclosure.MspLastRunDate
LEFT JOIN LOANCARE.LossMitigation lm ON OriginalLoan.LoanNumber = LM.LoanNumber AND OriginalLoan.MspLastRunDate = LM.MspLastRunDate
left join MSPLASTRUN M on Loan.MspLastRunDate = m.DataDate
Where LoType in ('9') AND InvestorId <> 'ACT' AND CAST(FIRSTPRINCIPALBALANCE AS MONEY) > 1 and Loan.MspLastRunDate = m.DataDate),

GNMA_EOM AS (SELECT Loan.MspLastRunDate, Loan.LoanNumber, OldLoanNumber, InvestorId, FirstPrincipalBalance AS UPB, loType, 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del','LoanCare' as DataSource, LossMitTemplateName, LossMitStatusCode

FROM LoanCare.Loan
INNER JOIN LoanCare.OriginalLoan ON OriginalLOAN.LoanNumber = Loan.LoanNumber AND OriginalLoan.MspLastRunDate = Loan.MspLastRunDate
LEFT JOIN LoanCare.Foreclosure ON loan.LoanNumber = Foreclosure.LoanNumber and loan.MspLastRunDate = Foreclosure.MspLastRunDate
LEFT JOIN LOANCARE.LossMitigation lm ON OriginalLoan.LoanNumber = LM.LoanNumber AND OriginalLoan.MspLastRunDate = LM.MspLastRunDate
left join MSPLASTRUN M on Loan.MspLastRunDate = m.DataDate
Where LoType in ('1', '2', '9') AND InvestorId <> 'ACT' AND CAST(FIRSTPRINCIPALBALANCE AS MONEY) > 1 and Loan.MspLastRunDate = m.DataDate), 

FHA AS (SELECT (((SELECT sum(CAST(UPB AS MONEY)) from FHA_EOM where Del <> 'Current'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM FHA_EOM))*100) as DelPerCent),

VA AS (SELECT (((SELECT sum(CAST(UPB AS MONEY)) from VA_EOM where Del <> 'Current'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM VA_EOM))*100) as DelPerCent),

USDA AS (SELECT (((SELECT sum(CAST(UPB AS MONEY)) from USDA_EOM where Del <> 'Current'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM USDA_EOM))*100) as DelPerCent),

TOTAL AS (SELECT (((SELECT sum(CAST(UPB AS MONEY)) from GNMA_EOM where Del <> 'Current'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM GNMA_EOM))*100) as DelPerCent),

FHA_NON_COVID AS (SELECT (((SELECT sum(CAST(UPB AS MONEY)) from FHA_EOM where Del <> 'Current'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM FHA_EOM))*100-
(((SELECT sum(CAST(UPB AS MONEY)) from USDA_EOM where Del <> 'Current' AND (LossMitStatusCode='A' AND LossMitTemplateName='PDFORB'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM FHA_EOM))*100))) as DelPerCent),

VA_NON_COVID AS (SELECT (((SELECT sum(CAST(UPB AS MONEY)) from VA_EOM where Del <> 'Current'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM VA_EOM))*100-
(((SELECT sum(CAST(UPB AS MONEY)) from VA_EOM where Del <> 'Current' AND (LossMitStatusCode='A' AND LossMitTemplateName='PDFORB'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM VA_EOM))*100))) as DelPerCent),

USDA_NON_COVID AS (SELECT (((SELECT sum(CAST(UPB AS MONEY)) from USDA_EOM where Del <> 'Current'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM USDA_EOM))*100-
(((SELECT sum(CAST(UPB AS MONEY)) from USDA_EOM where Del <> 'Current' AND (LossMitStatusCode='A' AND LossMitTemplateName='PDFORB'))/((SELECT SUM(CAST(UPB AS MONEY)) FROM USDA_EOM))*100))) as DelPerCent)


SELECT ('FHA') AS Investor, * FROM FHA
UNION 
SELECT ('VA'), * FROM VA
UNION 
SELECT ('USDA'), * FROM USDA
UNION
SELECT ('TOTAL'), * FROM TOTAL
UNION
SELECT ('FHA_NON_COVID'), * FROM FHA_NON_COVID
UNION 
SELECT ('VA_NON_COVID'), * FROM VA_NON_COVID
UNION 
SELECT ('USDA_NON_COVID'), * FROM USDA_NON_COVID



