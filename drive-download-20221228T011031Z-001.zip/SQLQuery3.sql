DECLARE
@d date = '2022-12-02'

;

with  

db_loans as (SELECT dbo.MWSLOS.DirectBoardingToSubservicer, dbo.MWSLOS.SubServicerLoanNumber as LoanNumber, dbo.MWSLOS.FundingDate, dbo.MWSLOS.InvestorCompanyName, dbo.MWSLOS.InvestorPurchasedDate, dbo.MWSLOS.LoanAmount AS pv, dbo.MWSLOS.PurchasePrincipalBalance, 
dbo.PurchasedLoans.PurchaseBalance, dbo.PurchasedLoans.PuchaseWireDate, dbo.MWSLOS.TransferDate, dbo.MWSLOS.LPIDate AS LPI_Date_OPS, dbo.MWSLOS.InvestorPurchaseLPI, dbo.MWSLOS.FirstPaymentDueDate, dbo.MWSLOS.InterestRate
FROM dbo.MWSLOS LEFT JOIN dbo.PurchasedLoans ON dbo.MWSLOS.LosLoanId = dbo.PurchasedLoans.PurchasedLoanNumber
WHERE dbo.MWSLOS.DirectBoardingToSubservicer='Y'),

dbo_ServicingLoan as (Select L.InvestorId, l.LoanNumber, l.LastFullPaymentDate, cast(l.AnnualInterestRate as float) as AnnualInterestRate, l.FirstPrincipalBalance, cast(l.NextPaymentDueDate as date) as NextPaymentDueDate, l.FirstPAndIAmount, o.OldLoanNumberFormatted, 
cast(l.LoanTerm as int) lt 
from LoanCare.Loan L 
INNER JOIN LoanCare.OriginalLoan O ON L.LoanNumber = O.LoanNumber AND L.MspLastRunDate = O.MspLastRunDate
WHERE l.MspLastRunDate = @d -1 and cast(FirstPrincipalBalance as money) > 0 

union 
select 	l.INV_CODE, l.LOAN_NBR_SERVICER,l.PMT_RECEIVED_DATE_LAST, cast(l.INT_RATE as float), l.PRIN_BALANCE_CURR, cast(l.PMT_DUE_DATE_NEXT as date), l.PMT_AMT_PI, l.LOAN_NBR_OTHERFormatted, cast(l.TERM as int)
from phh.Loan l
where DATA_ASOF_DATE = '2022-12-02' and cast(PRIN_BALANCE_CURR as money) > 0),

initial_loan_population as (SELECT db_loans.DirectBoardingToSubservicer, dbo_ServicingLoan.InvestorID, dbo_ServicingLoan.LoanNumber, dbo_ServicingLoan.OldLoanNumberFormatted, db_loans.PurchasePrincipalBalance, dbo_ServicingLoan.FirstPAndIAmount, db_loans.FirstPaymentDueDate, 
dbo_ServicingLoan.NextPaymentDueDate, db_loans.InvestorPurchaseLPI, db_loans.LPI_Date_OPS, db_loans.PurchaseBalance, dbo_ServicingLoan.LastFullPaymentDate AS LPIDatesub, db_loans.TransferDate, db_loans.InterestRate, db_loans.pv, 
DateDiff(m,FirstPaymentDueDate,NextPaymentDueDate)+1 AS PMT#, db_loans.PuchaseWireDate, dbo_ServicingLoan.AnnualInterestRate/12 as rate
FROM db_loans LEFT JOIN dbo_ServicingLoan ON db_loans.LoanNumber = dbo_ServicingLoan.LoanNumber
WHERE db_loans.DirectBoardingToSubservicer IN ('Y')
),

final_initial_loan_population as (SELECT  ilp.DirectBoardingToSubservicer, dbo_ServicingLoan.InvestorID, dbo_ServicingLoan.LoanNumber, dbo_ServicingLoan.OldLoanNumberFormatted,  ilp.PurchasePrincipalBalance, dbo_ServicingLoan.FirstPrincipalBalance, 
dbo_ServicingLoan.FirstPAndIAmount,  ilp.FirstPaymentDueDate, dbo_ServicingLoan.NextPaymentDueDate,  ilp.InvestorPurchaseLPI,  ilp.LPI_Date_OPS , dbo_ServicingLoan.LastFullPaymentDate AS  LPIDatesub ,  ilp.TransferDate,  ilp.InterestRate,  
ilp.pv,  ilp.PurchaseBalance,  ilp.PuchaseWireDate,  ilp.PMT#, Round((pv * ((rate * Power((1+rate), lt)/(POWER((1+rate), lt)-1)))), 2) as PeriodicPayment, lt, rate
FROM  initial_loan_population ilp  LEFT JOIN dbo_ServicingLoan ON  ilp.LoanNumber = dbo_ServicingLoan.LoanNumber
WHERE PMT# > 1
),

schedule as (SELECT final_initial_loan_population.LoanNumber, final_initial_loan_population.InterestRate AS Int_rate, final_initial_loan_population.FirstPaymentDueDate, final_initial_loan_population.NextPaymentDueDate, final_initial_loan_population.FirstPAndIAmount AS principal_int_amt_1, 
final_initial_loan_population.pv, PeriodicPayment * PMT# AS TotalPayment ,(POWER((1+rate), PMT#)-1)/(POWER((1+rate), lt)-1) * pv as TotalPrincipal, (PeriodicPayment * PMT#) - ((POWER((1+rate), PMT#)-1)/(POWER((1+rate), lt)-1) * pv )

AS [INT Due], PeriodicPayment AS [Prin Due]
FROM final_initial_loan_population)

select * from final_initial_loan_population
