SELECT MortgagorLastName, LoanCare.Loan.BankruptcyCode, LoanCare.Borrower.CoMortgagorLastName, LoanCare.Loan.LoanNumber, LoanCare.Loan.ForeclosureStopCode, LoanCare.Loan.LoType, LoanCare.Property.PropertyTypeFnmaCode, 
LoanCare.Loan.LoanReoStatusCode, LoanCare.Loan.LoanLossMitStatusCode, LoanCare.Loan.ForeclosureStatusCode, LoanCare.Loan.CategoryCode, LoanCare.Loan.InvestorId, LoanCare.Property.PropertyAlphaStateCode, 
LoanCare.Property.OccupancyCode, LoanCare.Delinquency.DelinquencyIndicator, Bankruptcy.BkrFilingDate, BkrDismissalDate, BkrDischargeDate, BkrChapterType,
LoanCare.Borrower.MspLastRunDate
FROM LoanCare.Borrower INNER JOIN LoanCare.Loan ON LoanCare.Borrower.MspLastRunDate = LoanCare.Loan.MspLastRunDate AND LoanCare.Borrower.LoanNumber = LoanCare.Loan.LoanNumber 
INNER JOIN LoanCare.Property ON LoanCare.Loan.MspLastRunDate = LoanCare.Property.MspLastRunDate AND LoanCare.Loan.LoanNumber = LoanCare.Property.LoanNumber 
LEFT JOIN LoanCare.Delinquency ON LoanCare.Property.MspLastRunDate = LoanCare.Delinquency.MspLastRunDate AND LoanCare.Property.LoanNumber = LoanCare.Delinquency.LoanNumber 
INNER JOIN LoanCare.OriginalLoan ON LoanCare.Property.LoanNumber = LoanCare.OriginalLoan.LoanNumber AND LoanCare.Property.MspLastRunDate = LoanCare.OriginalLoan.MspLastRunDate
LEFT JOIN LoanCare.Bankruptcy ON OriginalLoan.LoanNumber = Bankruptcy.LoanNumber AND OriginalLoan.MspLastRunDate = Bankruptcy.MspLastRunDate
WHERE LoanCare.Borrower.MspLastRunDate='2022-05-31';
