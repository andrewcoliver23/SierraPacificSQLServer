with phh_ny as (
select L.LOAN_NBR_SERVICER, PRIN_BALANCE_CURR, LOAN_TYPE
from phh.loan l inner join phh.Property p ON L.LOAN_NBR_SERVICER = P.LOAN_NBR_SERVICER AND L.DATA_ASOF_DATE = P.DATA_ASOF_DATE
LEFT JOIN PHH.Foreclosure F ON P.LOAN_NBR_SERVICER = F.LOAN_NBR_SERVICER AND P.DATA_ASOF_DATE = F.DATA_ASOF_DATE
LEFT JOIN [SPM.ExemptLoans] E ON L.LOAN_NBR_SERVICER = E.LoanNumber
WHERE L.DATA_ASOF_DATE = '2022-09-30' AND CAST(PRIN_BALANCE_CURR as money) > 1 and LOAN_REO_STATUS_CODE <> 'A' AND L.INV_CODE Not In ('1S1','47Y','ACT','4C9','30M') AND E.LoanNumber IS NULL),

LC_NY AS (
SELECT L.LoanNumber, FirstPrincipalBalance, LoType
FROM LoanCare.Loan L INNER JOIN LoanCare.PROPERTY P ON L.LoanNumber = P.LoanNumber AND L.MspLastRunDate = P.MspLastRunDate
LEFT JOIN Loancare.Foreclosure F on p.LoanNumber = f.LoanNumber and p.MspLastRunDate = f.MspLastRunDate
WHERE L.MspLastRunDate = '2022-09-30' AND CAST(FIRSTPRINCIPALBALANCE AS MONEY) > 1 and LoanReoStatusCode <> 'A' and L.InvestorId <> 'ACT'),

ALL_NY AS (
SELECT * FROM phh_ny
UNION
SELECT * FROM LC_NY)

SELECT LOAN_TYPE, COUNT(LOAN_NBR_SERVICER), SUM(cast(prin_balance_curr as money))
from ALL_NY
GROUP BY LOAN_TYPE