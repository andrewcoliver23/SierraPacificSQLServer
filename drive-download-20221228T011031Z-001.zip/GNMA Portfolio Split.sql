WITH LC_VINTAGE AS (
SELECT LoanCare.Loan.MspLastRunDate, Cast(LoanCare.Loan.LoanNumber as varchar) as LoanNumber, LoType as LoanType,CAST(FirstPrincipalBalance AS MONEY) AS FirstPrincipalBalance, LoanCare.Loan.LoanReoStatusCode, LoanCare.Loan.PaymentInFullStopCode, LoanClosingDate as FundingDate,
LoanCare.Property.PropertyAlphaStateCode as PropertyState, LoanCare.Loan.InvestorId, LoanCare.Loan.ForeclosureStatusCode, LoanCare.Loan.HiType, LoanCare.Loan.LoType, 'LoanCare' as DataSource, loan.AnnualInterestRate, OriginalLoan.OldLoanNumber
FROM LoanCare.Loan INNER JOIN LoanCare.Property ON LoanCare.Loan.MspLastRunDate = LoanCare.Property.MspLastRunDate AND LoanCare.Loan.LoanNumber = LoanCare.Property.LoanNumber
INNER JOIN LOANCARE.OriginalLoan ON Property.LoanNumber = OriginalLoan.LoanNumber and Property.MspLastRunDate = OriginalLoan.MspLastRunDate
WHERE Loan.MspLastRunDate = '2022-09-30' AND CAST(FirstPrincipalBalance AS MONEY) > 1 AND LoanCare.Loan.LoanReoStatusCode <> 'A' AND LoanCare.Loan.PaymentInFullStopCode <> '1' AND LoanCare.Loan.InvestorId <> 'ACT')


SELECT LoanType, count(LoanNumber) AS #, sum(FirstPrincipalBalance) as UPB, (select sum(FirstPrincipalBalance))/(select sum(FirstPrincipalBalance) FROM LC_VINTAGE where InvestorId in ('6BV')) AS '%'
from LC_VINTAGE
WHERE InvestorId IN ('6BV')
GROUP BY LoanType