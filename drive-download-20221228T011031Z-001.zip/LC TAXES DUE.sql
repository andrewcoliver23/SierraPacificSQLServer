WITH LC_TaxLoanDataPull AS (
SELECT LoanCare.Loan.MspLastRunDate, LoanCare.Loan.LoanNumber, LoanCare.Loan.InvestorId, LoanCare.Loan.FirstPrincipalBalance, LoanCare.Loan.PaymentInFullDate, LoanCare.Loan.PaymentInFullStopCode, LoanCare.Loan.LoType, 
LoanCare.Loan.EscrowedIndicator, LoanCare.Tax.TaxPayeeCode, LoanCare.Tax.TaxDisbursementType, LoanCare.Tax.TaxDisbursementDueDate, (datepart(mm, TaxDisbursementDueDate)) as TaxMonth, LoanCare.Tax.TaxDisbursementAmount, LoanCare.Property.CityName, LoanCare.Property.PropertyAlphaStateCode, 
LoanCare.Property.FipsCountyCode, LoanCare.Property.CountyCode, LoanCare.Loan.ForeclosureStatusCode, LoanCare.Loan.BankruptcyStatusCodeM, LoanCare.Loan.LoanLossMitStatusCode, LoanCare.Foreclosure.FcSaleDate
FROM LoanCare.Loan INNER JOIN LoanCare.Tax ON LoanCare.Loan.LoanNumber = LoanCare.Tax.LoanNumber 
INNER JOIN LoanCare.Property ON LoanCare.Loan.LoanNumber = LoanCare.Property.LoanNumber
LEFT JOIN LoanCare.Foreclosure ON LoanCare.Loan.LoanNumber = LoanCare.Foreclosure.LoanNumber
WHERE LoanCare.Loan.InvestorId Not In ('A60','5RB','4C9') AND cast(LoanCare.Loan.FirstPrincipalBalance as money) > 0 AND LoanCare.Loan.PaymentInFullStopCode= '0' AND LoanCare.Loan.EscrowedIndicator='Y')

SELECT DISTINCT LC_TaxLoanDataPull.LoanNumber, LC_TaxLoanDataPull.InvestorId, LC_TaxLoanDataPull.PaymentInFullDate, LC_TaxLoanDataPull.LoType, LC_TaxLoanDataPull.EscrowedIndicator, LC_TaxLoanDataPull.TaxPayeeCode, 
LC_TaxLoanDataPull.TaxDisbursementType, LC_TaxLoanDataPull.TaxDisbursementDueDate, LC_TaxLoanDataPull.TaxDisbursementAmount, LC_TaxLoanDataPull.TaxMonth, LC_TaxLoanDataPull.CityName, LC_TaxLoanDataPull.PropertyAlphaStateCode, 
LC_TaxLoanDataPull.ForeclosureStatusCode, LC_TaxLoanDataPull.FcSaleDate, LC_TaxLoanDataPull.BankruptcyStatusCodeM, LC_TaxLoanDataPull.LoanLossMitStatusCode
FROM LC_TaxLoanDataPull
WHERE LC_TaxLoanDataPull.TaxMonth = 7
ORDER BY LC_TaxLoanDataPull.LoanNumber;




