WITH PHH_DEL AS (
SELECT iIf([INVESTORID] In ('4EF','4EG', '361', '362', '363'),'FNMA',IIf([INVESTORID] in ('5AK', '364'),'FHLMC',
IIf([INVESTORID] In ('A60','ACT', '360', '359', '358'),'Portfolio','Others'))) as Investor,
CASE 
WHEN
ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) = 0
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del', COUNT(Loan.LoanNumber) as #, SUM(cast(FirstPrincipalBalance as money)) as UPB
FROM DMI.DAILYMASTERFIELDSLoan Loan INNER JOIN DMI.DAILYMASTERFIELDSDelinquency Delinquency ON Loan.LoanNumber = Delinquency.LoanNumber AND LOAN.MspLastRunDate = Delinquency.MspLastRunDate
LEFT JOIN DMI.DAILYMASTERFIELDSForeclosure Foreclosure ON Delinquency.LoanNumber = Foreclosure.LoanNumber AND Delinquency.MspLastRunDate = Foreclosure.MspLastRunDate
WHERE LOAN.MspLastRunDate = '2021-9-30' AND CAST(FirstPrincipalBalance AS MONEY) > 1
GROUP BY IIf([INVESTORID] In ('4EF','4EG', '361', '362', '363'),'FNMA',IIf([INVESTORID] in ('5AK', '364'),'FHLMC',IIf([INVESTORID] In ('A60','ACT', '360', '359', '358'),'Portfolio','Others'))), 
CASE 
WHEN
ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) = 0
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01)) >= 4
THEN 'D120'
ELSE 'CURRENT'
END),

LC_DEL AS (
SELECT IIf([InvestorID] In ('4EF','4EG', '361', '362', '363'),'FNMA',IIf([InvestorID] in ('5AK', '364'),'FHLMC',IIf([InvestorID] In ('A60','ACT', '360', '359', '358'),'Portfolio',IIF([InvestorID] in ('6BV', 'XBV'), 'GNMA', 'Others'))))
AS Investor,
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del', COUNT(Loan.LoanNumber) as #, SUM(cast(FirstPrincipalBalance as money)) as UPB 
FROM LoanCare.Loan INNER JOIN LOANCARE.Delinquency ON LOAN.LoanNumber = Delinquency.LoanNumber AND LOAN.MspLastRunDate = Delinquency.MspLastRunDate
WHERE LOAN.MspLastRunDate = '2021-9-30' AND CAST(FirstPrincipalBalance AS MONEY) >1 AND Loan.LoanReoStatusCode <> 'A' AND InvestorId NOT IN ('4C9')
GROUP BY IIf([InvestorID] In ('4EF','4EG', '361', '362', '363'),'FNMA',IIf([InvestorID] in ('5AK', '364'),'FHLMC',IIf([InvestorID] In ('A60','ACT', '360', '359', '358'),'Portfolio',iif([InvestorID] in ('6BV', 'XBV'), 'GNMA', 'Others')))), 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END),

ALL_DEL AS 
(SELECT * FROM PHH_DEL
UNION
SELECT * FROM LC_DEL)

SELECT concat(rOUND(100*((select sum(UPB) WHERE Investor = 'FNMA')/(SELECT SUM(UPB) FROM ALL_DEL WHERE Investor = 'FNMA')), 2), '%') AS FNMA_TOTAL_DEL, 
concat(rOUND(100*((select sum(UPB) WHERE Investor = 'FHLMC')/(SELECT SUM(UPB) FROM ALL_DEL WHERE Investor = 'FHLMC')), 2), '%') AS FHLMC_TOTAL_DEL,
concat(rOUND(100*((select sum(UPB) WHERE Investor = 'GNMA')/(SELECT SUM(UPB) FROM ALL_DEL WHERE Investor = 'GNMA')), 2), '%') AS GNMA_TOTAL_DEL,
concat(rOUND(100*((select sum(UPB) WHERE Investor = 'Portfolio')/(SELECT SUM(UPB) FROM ALL_DEL WHERE Investor = 'Portfolio')), 2), '%') AS PORT_TOTAL_DEL
FROM ALL_DEL
WHERE DEL NOT IN ('Current')
GROUP BY Investor