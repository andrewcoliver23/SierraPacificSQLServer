WITH Covid_loansData (MaxOfMspLastRun,
LoanNumber, LossMitTypeCode)
AS (
SELECT Max(LoanCare.LossMitigation.MspLastRunDate) AS MaxOfMspLastRunDate, LoanCare.LossMitigation.LoanNumber, LoanCare.LossMitigation.LossMitTemplateName
FROM LoanCare.LossMitigation
GROUP BY LoanCare.LossMitigation.LoanNumber, LoanCare.LossMitigation.LossMitTemplateName
HAVING (((Max(LoanCare.LossMitigation.MspLastRunDate))>'2020-03-01') AND ((LoanCare.LossMitigation.LossMitTemplateName)='PDFORB'))
)

INSERT INTO Covid_loansData (MaxOfMspLastRunDate, SubservicerName, LoanNumber, LossMitTemplateName, LossMitTypeCode, [STart Date], [investor id] )
SELECT [10-8-2021 Active Forb].MspLastRunDate, [10-8-2021 Active Forb].DataSource, [10-8-2021 Active Forb].LoanNumber, [10-8-2021 Active Forb].LossMitTemplateName, [10-8-2021 Active Forb].LossMitTypeCode, [10-8-2021 Active Forb].LossMitStatusChangeDate, dbo_ServicingLoan.InvestorID
FROM ([10-8-2021 Active Forb] LEFT JOIN Covid_loansData ON [10-8-2021 Active Forb].LoanNumber = Covid_loansData.LoanNumber) INNER JOIN (dbo_ServicingLossMitigation INNER JOIN dbo_ServicingLoan ON dbo_ServicingLossMitigation.LoanNumber = dbo_ServicingLoan.LoanNumber) ON ([10-8-2021 Active Forb].LoanNumber = dbo_ServicingLossMitigation.LoanNumber) AND ([10-8-2021 Active Forb].LoanNumber = dbo_ServicingLoan.LoanNumber)
WHERE (((Covid_loansData.LoanNumber) Is Null));


SELECT *
FROM Covid_loansData