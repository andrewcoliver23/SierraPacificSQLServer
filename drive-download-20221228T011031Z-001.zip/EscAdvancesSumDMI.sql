WITH LoanCareEscAdvance AS ( 
SELECT LoanCare.Escrow.LoanNumber, [EscrowExpdAdvanceBalance] AS EscAdv, LoanCare.Escrow.MspLastRunDate, LoanCare.Loan.InvestorId, 
IIf([InvestorID] In ('4EF','4EG'),'FNMA',IIf([InvestorID]='5AK','FHLMC',IIf([InvestorID] In ('A60','XBV'),'Portfolio','GNMA'))) 
AS Investor, Escrow.OverOrShortAmount, LoanCare.Escrow.EscrowBalance, LoanCare.Escrow.LastAnalysisDate, LoanCare.Escrow.LastAnalysisOsSpreadMonths, LoanCare.Escrow.LastAnalysisEffectiveDate, 
LoanCare.Loan.SuspenseBalance, DelinquencyIndicator, IIF([DelinquencyIndicator] = '1', '30 Days', IIF([DelinquencyIndicator] = '2', '60 Days', IIF([DelinquencyIndicator] = '3', '90 Days', 
iif([DelinquencyIndicator] = '4', '120+', 'Current')))) as DelqIndicator
FROM LoanCare.Loan INNER JOIN LoanCare.Escrow ON LoanCare.Loan.MspLastRunDate = LoanCare.Escrow.MspLastRunDate AND LoanCare.Loan.LoanNumber = LoanCare.Escrow.LoanNumber
LEFT JOIN LoanCare.Delinquency ON (LoanCare.Escrow.LoanNumber = LoanCare.Delinquency.LoanNumber) AND (LoanCare.Escrow.MspLastRunDate = LoanCare.Delinquency.MspLastRunDate)
WHERE ((Cast([EscrowExpdAdvanceBalance] as money) <> 0) AND ((LoanCare.Escrow.MspLastRunDate) = '2021-04-30') AND ((LoanCare.Loan.InvestorId)<>'4C9'))),

DMIEscAdvance AS (
SELECT DMI.DailyMasterFieldsLoan.LoanNumber, CAST([EscrowExpdAdvanceBalance] AS money) AS [EscAdv], DMI.DailyMasterFieldsLoan.MspLastRunDate, DMI.DailyMasterFieldsLoan.InvestorId, 
IIf([InvestorID] In ('363','362', '361'),'FNMA',IIf([InvestorID]='364','FHLMC',IIf([InvestorID] In ('359','360'),'Portfolio','Interim Servicing'))) 
AS Investor, 
DMI.DailyMasterFieldsLoan.OverOrShortAmount, DMI.DailyMasterFieldsLoan.EscrowBalance, DMI.DailyMasterFieldsLoan.LastAnalysisDate, 
DMI.DailyMasterFieldsLoan.LastAnalysisOsSpreadMonths, DMI.DailyMasterFieldsLoan.LastAnalysisEffectiveDate, DMI.DailyMasterFieldsLoan.SuspenseBalance, DMI.DailyMasterFieldsDelinquency.DelinquencyIndicator, IIF([DelinquencyIndicator] = '1', '30 Days', IIF([DelinquencyIndicator] = '2', '60 Days', IIF([DelinquencyIndicator] = '3', '90 Days', 
iif([DelinquencyIndicator] = '4', '120+', 'Current')))) as DelqIndicator
FROM DMI.DailyMasterFieldsLoan INNER JOIN DMI.DailyMasterFieldsDelinquency ON (DMI.DailyMasterFieldsLoan.MspLastRunDate = DMI.DailyMasterFieldsDelinquency.MspLastRunDate) AND 
(DMI.DailyMasterFieldsLoan.LoanNumber = DMI.DailyMasterFieldsDelinquency.LoanNumber)
WHERE Cast([EscrowExpdAdvanceBalance] as money)<>0 AND DMI.DailyMasterFieldsLoan.MspLastRunDate= '2021-04-30' AND InvestorId <> '868'),

All_advances as (

SELECT * FROM LoanCareEscAdvance
UNION
SELECT * FROM DMIEscAdvance)

select Investor, DelqIndicator, COUNT(LoanNumber) AS #, SUM(EscAdv) AS "$"
from All_advances
GROUP BY Investor, DelqIndicator
ORDER BY Investor