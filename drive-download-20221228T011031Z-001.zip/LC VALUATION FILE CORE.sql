SELECT L. MspLastRunDate, L.LoanNumber, l.InvestorId, l.PendPoolContractNumber, p.CityName, p.PropertyAlphaStateCode, p.PropertyZipCode, 
p.PropertyTypeFnmaCode, p.OccupancyCode, l.LoType, l.AnnualInterestRate, O.OriginalMortgageAmount, l.FirstPrincipalBalance, 
O.FirstDueDate, L.LoanMaturesDate, L.FirstPAndIAmount, O.OriginalLoanTerm, L.LoanTerm,  L.OriginalLoanToValueRatio, L.LoanToValueRatio, 
L.NextPaymentDueDate, ArmPlanId, P.PropertyValueAmount, InterestOnEscrowFlag, EscrowBalance, HiType, TAndIMonthlyAmount, TotalMonthlyPayment,
P.NumberOfUnits, FcStopCode, CountyCode, ArmIndexCode1, ArmIrMarginRate, ArmIrChangePeriod,ArmIrMaxLifeIncrRate, ArmIrMaxLifeDecrRate, 
ConvertibleStatusCode, ArmNextOptPiChangeDate, ArmNextIrEffectiveDate, ArmNextPiEffectiveDate, ArmPiNegativeAmortCapCode,
ArmPbNegativeAmortBal, ArmPbNegativeAmortPct, ArmIrFullAmortCode, PaymentPeriod, LoanClosingDate, RemainingTerm, 
InterestOnlyLoanIndicator, DelinquencyClassCode, FnmaFeatureCode1, FnmaFeatureCode2, FnmaFeatureCode3, FnmaFeatureCode4,
ArmOrigOptPiChangeDate, BadCheckTablePosition01, BadCheckTablePosition02, BadCheckTablePosition03, BadCheckTablePosition04, 
BadCheckTablePosition05,BadCheckTablePosition06, BadCheckTablePosition07, BadCheckTablePosition08, BadCheckTablePosition09,  
BadCheckTablePosition10, BadCheckTablePosition11, BadCheckTablePosition12, EscrowExpdAdvanceBalance, RecoverCorpAdvanceBalance,
NonRecCorpAdvanceBalance, ThirdPartyRecoverableCaBal, BankruptcyStatusCodeM, BankruptcyCode, ArmOriginalInterestRate, S
FROM LoanCare.Loan L inner join LoanCare.Property p on l.LoanNumber = p.LoanNumber and l.MspLastRunDate = p.MspLastRunDate
INNER JOIN LOANCARE.OriginalLoan o ON P.LoanNumber = O.LoanNumber AND P.MspLastRunDate = O.MspLastRunDate
LEFT JOIN dbo.MWSLOS master ON L.LoanNumber = master.SubServicerLoanNumber
LEFT JOIN LoanCare.NewArm na ON L.LoanNumber = NA.LoanNumber AND L.MspLastRunDate = NA.MspLastRunDate
LEFT JOIN LoanCare.ArmInterest AI on l.LoanNumber = AI.LoanNumber and l.MspLastRunDate = AI.MspLastRunDate
LEFT JOIN LOANCARE.ArmTerms A ON L.LoanNumber = A.LoanNumber AND L.MspLastRunDate = A.MspLastRunDate
LEFT JOIN LOANCARE.ArmPayment AP ON L.LoanNumber = AP.LoanNumber AND L.MspLastRunDate = AP.MspLastRunDate
LEFT JOIN LOANCARE.Escrow e ON L.LoanNumber = E.LoanNumber AND L.MspLastRunDate = E.MspLastRunDate
LEFT JOIN LOANCARE.Foreclosure f on L.LoanNumber = F.LoanNumber AND L.MspLastRunDate = F.MspLastRunDate
LEFT JOIN LOANCARE.Delinquency D ON L.LoanNumber = D.LoanNumber AND L.MspLastRunDate = D.MspLastRunDate
LEFT JOIN LOANCARE.CorporateAdvTransactions CAT ON L.LoanNumber = CAT.LoanNumber AND L.MspLastRunDate = CAT.MspLastRunDate
LEFT JOIN LOANCARE.CorporateAccounting CA ON L.LoanNumber = CA.LoanNumber AND L.MspLastRunDate = CA.MspLastRunDate

