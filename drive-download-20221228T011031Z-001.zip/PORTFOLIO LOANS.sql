WITH PHH_PORT AS  (SELECT l.LOAN_NBR_SERVICER AS LOANnUMBER, L.PRIN_BALANCE_CURR, L.INV_CODE, L.DATA_ASOF_DATE, INV_NAME as AlphaCode
FROM PHH.Loan L innER join PHH.INVESTOR I ON L.LOAN_NBR_SERVICER = I.LOAN_NBR_SERVICER AND L.DATA_ASOF_DATE = I.DATA_ASOF_DATE
WHERE L.INV_CODE  In  ('XBV','1S2','A60','1S0')   AND   L.DATA_ASOF_DATE ='2022-09-30'  and cast(PRIN_BALANCE_CURR as money) > 1)  ,

LC_PORT AS ( SELECT L.LoanNumber, L.FirstPrincipalBalance, L.InvestorId, L.MspLastRunDate, AlphaCode
FROM Loancare.Loan L inner join LoanCare.InvestorCategory O on l.LoanNumber = o.LoanNumber and l.MspLastRunDate = o.MspLastRunDate
WHERE L.InvestorId In ('XBV','1S2','A60','1S0')  AND  L.MspLastRunDate ='2022-9-30'   and cast(FirstPrincipalBalance as money) > 1 and LoanReoStatusCode <> 'A'
),

gunion as (
select * from phh_port
union
select * from lc_port)

select 
CASE
WHEN INV_CODE IN ('1S0', 'XBV')
THEN 'Pending Transfer'
when INV_CODE in ('A60') and AlphaCode IN ('FNMA', 'FHLM')
then 'Pending Transfer'
WHEN INV_CODE IN ('A60', '1S2')
THEN 'Pending RePool'
end as 'Breakout' ,
count(LoanNumber) as loanNumber, sum(cast(PRIN_BALANCE_CURR AS MONEY)) AS UPB from gunion
group by 
CASE
WHEN INV_CODE IN ('1S0', 'XBV')
THEN 'Pending Transfer'
when INV_CODE in ('A60') and AlphaCode IN ('FNMA', 'FHLM')
then 'Pending Transfer'
WHEN INV_CODE IN ('A60', '1S2')
THEN 'Pending RePool'
end
order by 1 desc
