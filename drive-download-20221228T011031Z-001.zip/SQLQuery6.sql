with LC AS (
SELECT DISTINCT(Loan.LoanNumber) as LoanNumber
from loancare.loan inner join loancare.property on loan.LoanNumber = property.LoanNumber
where PropertyAlphaStateCode = 'CA' and Loan.MspLastRunDate >= '2021-10-01' and Loan.MspLastRunDate <= '2021-12-31' AND Cast(FirstPrincipalBalance as money) > 1),

LoanCare_Serviced as (
SELECT loan.loannumber AS LoanNumber, Cast(loan.firstprincipalbalance as money) as UPB,Loan.MspLastRunDate as DataDate
from loancare.loan inner join loancare.property on loan.loannumber = property.LoanNumber and loan.MspLastRunDate = property.MspLastRunDate
where PropertyAlphaStateCode = 'CA' AND loan.MspLastRunDate >= '2021-10-01' AND loan.MspLastRunDate <= '2021-12-31' and Cast(FirstPrincipalBalance as money) > 1),

PHH AS (
SELECT DISTINCT(Loan.Loan_nbr_Servicer) AS LoanNumber
from phh.loan inner join phh.Property on LOAN.LOAN_NBR_SERVICER = Property.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = Property.DATA_ASOF_DATE
WHERE PROP_STATE = 'CA' AND LOAN.DATA_ASOF_DATE >= '2021-10-01' AND LOAN.DATA_ASOF_DATE <= '2021-12-31'),

PHH_Serviced as (
SELECT LOAN.LOAN_NBR_SERVICER AS LoanNumber, Cast(LOAN.PRIN_BALANCE_CURR as money) AS UPB, LOAN.DATA_ASOF_DATE AS DataDate
FROM PHH.Loan INNER JOIN PHH.Property ON PHH.Loan.LOAN_NBR_SERVICER = PROPERTY.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = PROPERTY.DATA_ASOF_DATE
WHERE PROPERTY.PROP_STATE = 'CA' AND loan.DATA_ASOF_DATE >= '2021-10-01' AND loan.DATA_ASOF_DATE <= '2021-12-31' and Cast(PRIN_BALANCE_CURR as money) > 1),

LC_ALL as (
select count(LC.LoanNumber) AS #, Sum(UPB) AS UPB
FROM LC INNER JOIN LoanCare_Serviced on LC.LoanNumber = LoanCare_Serviced.LoanNumber
WHERE DataDate = (Select max(DataDate) from LoanCare_Serviced))


SELECT * FROM PHH


