with PHH_DEL_LIST AS (SELECT 
CASE 
WHEN
FCL_STATUS = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 4
THEN 'D120'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) >= 5
THEN 'D150'
ELSE 'CURRENT'
END AS 'Del', LOAN_NBR_OTHERFormatted AS SPMLoanNumber,cast(PRIN_BALANCE_CURR as money) as UPB, Loan.LOAN_NBR_SERVICER as LoanNumber, FCL_STATUS, LOAN_LOSS_MIT_STATUS_CODE, PMT_DUE_DATE_NEXT, LOAN_TYPE, loan.DATA_ASOF_DATE
FROM PHH.Loan INNER JOIN PHH.Delinquency ON Loan.LOAN_NBR_SERVICER = Delinquency.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = Delinquency.DATA_ASOF_DATE
LEFT JOIN PHH.Foreclosure ON Delinquency.LOAN_NBR_SERVICER = Foreclosure.LOAN_NBR_SERVICER AND Delinquency.DATA_ASOF_DATE = Foreclosure.DATA_ASOF_DATE
WHERE LOAN.DATA_ASOF_DATE = EOMONTH(getdate(), -1) AND CAST(PRIN_BALANCE_CURR AS MONEY) >1 and INV_CODE NOT IN ('30M', '1S1')),

LC_DEL_LIST AS (
SELECT 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) = 4
THEN 'D120'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, datefromparts(datepart(year, getdate()), datepart(month, getdate()), 01)) >= 5
THEN 'D150'
ELSE 'CURRENT'
END AS 'Del',  OldLoanNumberFormatted,cast(FirstPrincipalBalance as money) as UPB, Loan.LoanNumber as LoanNumber, ForeclosureStatusCode, LoanLossMitStatusCode, NextPaymentDueDate, LoType, Loan.MspLastRunDate
FROM LoanCare.Loan INNER JOIN LOANCARE.Delinquency ON LOAN.LoanNumber = Delinquency.LoanNumber AND LOAN.MspLastRunDate = Delinquency.MspLastRunDate
inner join LoanCare.OriginalLoan O on Delinquency.LoanNumber = o.LoanNumber and Delinquency.MspLastRunDate = o.MspLastRunDate
WHERE LOAN.MspLastRunDate = EOMONTH(getdate(), -1) AND CAST(FirstPrincipalBalance AS MONEY) >1 AND Loan.InvestorId <> 'ACT' AND Loan.LoanReoStatusCode <> 'A')


SELECT * FROM PHH_DEL_LIST
WHERE DEL IN ('D090', 'D120', 'D150','FC')
UNION
SELECT * FROM LC_DEL_LIST
WHERE Del IN ('D090', 'D120', 'D150','FC')
