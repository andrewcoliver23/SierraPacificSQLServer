WITH PHH_DEL AS (
SELECT 
CASE 
WHEN
FCL_STATUS = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) = 0 
OR DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del', COUNT(Loan.LOAN_NBR_SERVICER) as #, SUM(cast(PRIN_BALANCE_CURR as money)) as UPB
FROM PHH.Loan INNER JOIN PHH.Delinquency ON Loan.LOAN_NBR_SERVICER = Delinquency.LOAN_NBR_SERVICER AND LOAN.DATA_ASOF_DATE = Delinquency.DATA_ASOF_DATE
LEFT JOIN PHH.Foreclosure ON Delinquency.LOAN_NBR_SERVICER = Foreclosure.LOAN_NBR_SERVICER AND Delinquency.DATA_ASOF_DATE = Foreclosure.DATA_ASOF_DATE
WHERE LOAN.DATA_ASOF_DATE = '2022-8-31' AND CAST(PRIN_BALANCE_CURR AS MONEY) >1 and INV_CODE NOT IN ('30M', '47Y')
GROUP BY CASE 
WHEN
FCL_STATUS = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) = 0
OR DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) = 1
THEN 'D030'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.PMT_DUE_DATE_NEXT, DATEFROMPARTS(datepart(yy, Loan.DATA_ASOF_DATE), datepart(mm, Loan.DATA_ASOF_DATE), 01)) >= 4
THEN 'D120'
ELSE 'CURRENT'
END),

LC_DEL AS (
SELECT 
CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END AS 'Del', COUNT(Loan.LoanNumber) as #, SUM(cast(FirstPrincipalBalance as money)) as UPB 
FROM LoanCare.Loan INNER JOIN LOANCARE.Delinquency ON LOAN.LoanNumber = Delinquency.LoanNumber AND LOAN.MspLastRunDate = Delinquency.MspLastRunDate
WHERE LOAN.MspLastRunDate = '2022-08-31' AND CAST(FirstPrincipalBalance AS MONEY) >1 AND Loan.LoanReoStatusCode <> 'A' AND InvestorId NOT IN ('4C9')
GROUP BY CASE 
WHEN
LOAN.ForeclosureStatusCode = 'A'
Then 'FC'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 1
OR DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 0
THEN 'D030'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 2
THEN 'D060'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) = 3
THEN 'D090'
WHEN DATEDIFF(m, Loan.NextPaymentDueDate, DATEFROMPARTS(datepart(yy, Loan.MspLastRunDate), datepart(mm, Loan.MspLastRunDate), 01) ) >= 4
THEN 'D120'
ELSE 'CURRENT'
END),

ALL_DEL AS 
(SELECT * FROM PHH_DEL
UNION
SELECT * FROM LC_DEL)

select Del, SUM(#) AS #, round(sum(UPB), 0) AS UPB, concat(rOUND(100*((select sum(UPB))/(select sum(UPB) FROM ALL_DEL)), 2), '%') AS '%'
FROM ALL_DEL
where upb > 0.01
GROUP BY Del
